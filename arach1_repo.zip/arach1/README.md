# Arach1

**Predator 7.1 × M** — a Metamath theorem prover coupled with a learned candidate ordering.

```bash
pip install -r requirements.txt
curl -L -o set.mm https://raw.githubusercontent.com/metamath/set.mm/develop/set.mm
python run.py --quick      # ~2 min end-to-end smoke test
python run.py              # the real run: prep 12k, m=10, p=0.8, benchmark
python run.py --prove peirce
```

See [SETUP.md](SETUP.md) for details. Papers and results are in [`docs/`](docs/);
the standalone self-certifying prover is in [`ascent/`](ascent/).

---

**Arach1 = Predator's calculus + a learned ordering.**

M never proves anything. It permutes the candidate list, so a wrong M costs time and *cannot* cost soundness — every proof is still checked by `metamath.py`, unchanged.

---

## Why this is where the leverage is

Breadth-first search touches roughly **b^d** nodes. On set.mm the measured median candidate pool is **b = 4,735**, so:

| | d=2 | d=4 | d=6 |
|---|---|---|---|
| Predator alone (b = 4735) | 2.2e7 | 5.0e14 | 1.1e22 |
| + M keeping top-20 | 4.0e2 | 1.6e5 | 6.4e7 |
| + M keeping top-5 | 2.5e1 | 6.2e2 | 1.6e4 |

Depth is useless at b = 4735 and cheap at b = 20. **M's job is to collapse b, not to prove theorems.**

And Predator already had the hook — no caller had ever passed it:

```python
sc_o = rank(gt, openers) if rank else [0.0]*len(openers)
pick = (closers by -sc_c) + (openers by -sc_o)[:48]
```

That **48** is the crux. Openers are capped, so unranked Predator keeps an arbitrary 48 of several thousand. Same 48 slots, filled by score.

---

## Files you need

In one directory: `set.mm`, `metamath.py`, `setmm_grammar.py`, `predator71.py`, `bench_p71.py`, `transcript.py`, `arach1.py`. Plus `numpy`. No other dependencies.

## Setup — build the parse cache once

set.mm takes ~25 s to parse; everything else reads a pickle instead.

```bash
python bench_p71.py --db set.mm --cache /tmp/setmm.pkl --out /tmp/x \
                    --scan 1 --max-logic 1 --chunk 0 0
```

Change `CACHE` at the top of `arach1.py` if you want it elsewhere.

---

## 1. Prep — turn set.mm proofs into training data

```bash
python arach1.py prep --chunk 0 12000
```

Three things happen, and each matters:

- **Proofs are converted to v45 shape.** A Metamath proof is a sequence of *labels* in reverse Polish; `transcript.py` runs the verifier's stack machine and logs each push, yielding a finite sequence of wffs where each line is a hypothesis or a direct consequence of earlier lines. That is Definition §205, and it's the same object as Definition 14.1, the verification transcript.
- **Proofs are inverted.** Human proofs run *forward*; Predator searches *backward*. Line *j* justified by rule *R* from premises *P* becomes `goal = wff(j) → apply R → subgoals = {wff(p)}`. Training a backward policy on forward lines teaches the wrong conditional.
- **Negatives come from the chronological prefix.** Only assertions declared *before* the target theorem, and only ones with a matching conclusion head — which is exactly the bucket `Index.candidates()` returns. Sampling from all 47,572 labels lets the model pick lemmas that didn't exist yet and inflates every number.

Scale: `--chunk 0 12000` gives roughly 300k rows in 20k decision groups, in about a minute. Use `--append` with successive chunks to build up the full database.

## 2. Train — m resamples of a random fraction p

```bash
python arach1.py train --m 10 --p 0.8
```

Trains **m independent models**, each on a random 80% of the decision groups, testing on the held-out 20%. You get a mean and a standard deviation instead of one number that might be luck.

Options: `--split chrono` splits by database position instead of randomly (stricter — no late theorem can teach the model about an earlier held-out one); `--epochs`, `--topk`.

Typical output:

```
run 0   pairwise 95.3%  |  prior  36.1%   M  56.6%  (top-5  94.8%)   median rank 1
...
over 3 resamples of a random 80%
  frequency prior  top-1   36.6% +/- 0.7
  M                top-1   59.2% +/- 2.1
  M                top-5   95.3% +/- 0.6
  delta            top-1  +22.6 pts
```

**Read the `prior` column first.** It's the frequency baseline — always pick the most-used rule. set.mm rule usage is very skewed (`syl` alone is 3% of all steps), so the prior is strong and beating it is the only evidence M learned anything. `top-5` is the number the branching argument needs.

The best run is saved to `/tmp/arach1_model.pkl`.

## 3. Prove one theorem

```bash
python arach1.py prove peirce
python arach1.py prove prcom --budget 20000 --depth 8 --wall 60
```

Runs the target **twice** — once with `rank=None`, once with `rank=M` — in the same process, at the same budget, against the same index state. Anything less isn't a comparison.

```
  goal        |- ( -. ph -> ( ph -> ps ) )
  human proof 2 logical steps
  indexed 121 assertions in 0.2s

  Predator alone (rank=None)   --       wall exp   8.3s  CV:--
  Arach1        (rank=M)       PROVED    412 exp   1.1s  4 st  CV:ok
```

Only closed theorems are accepted. A theorem with `$e` hypotheses has a conclusion that isn't a theorem on its own, and Arach1 will tell you so rather than score you for failing an unprovable goal.

## 4. Benchmark — easy / medium / hard

```bash
python arach1.py bench --per-band 10
```

Bands are graded by the **human** proof's logical-step count: easy 1–2, medium 3–5, hard 6–12. Targets come from the held-out tail of set.mm.

```
  band         Predator       Arach1    delta   CV rej
  easy          7/10 (5)     9/10 (7)       +2        0
  medium        2/10 (1)     5/10 (4)       +3        0
  hard          2/10 (0)     2/10 (0)       +0        0
```

---

## How to read the output — the one trap

**The parenthesised number is what counts.** set.mm contains many duplicate statements: 4.7% of its logical assertions share both conclusion and hypotheses with another label. When the base already contains a copy of your target, the prover closes it in one step and scores a solve without doing any reasoning.

Arach1 flags these as `lookup` and excludes them from the genuine count:

```
3ioran   7   lookup   2 exp  0.0s  1 st
hard     Predator 2/2 (genuine 0)
```

A 1-logic-step proof of a 7-step theorem is a duplicate, not skill. **Quote the genuine number.** This confound is not hypothetical — measured on set.mm, 12 of Predator's 15 solves were one-step lookups, leaving 3/52 genuine.

Other things worth knowing:

- `wall` in the expansions column means the per-side time limit hit, not exhaustion. Raise `--wall` before concluding anything about depth.
- `CV rej` must stay 0. A nonzero value means a certificate was rejected — treat it as a bug in the harness, not a curiosity. This is how a harness bug that inflated a score from 1/6 to a false 8/8 was caught.
- Ranking accuracy from `train` is a **proxy**. Solve rate from `eval`/`bench` is the thing.

---

## Suggested first session

```bash
python bench_p71.py --db set.mm --cache /tmp/setmm.pkl --out /tmp/x \
                    --scan 1 --max-logic 1 --chunk 0 0    # once, ~25 s
python arach1.py prep  --chunk 0 12000                    # ~1 min
python arach1.py train --m 10 --p 0.8                     # minutes
python arach1.py bench --per-band 10 --wall 30            # the real number
```

Then vary one thing at a time. `--depth` is the parameter to push once M is in place — that is the entire hypothesis, and `bench` is how you test it.

## Limitations, stated plainly

- **M is a linear model over nine hand-built features.** Deliberately. Two heuristics in this codebase were respectively slower-than-nothing and silently inert, and both would have looked like success to a model trained on the same broken signal. Beat the frequency prior with something simple before reaching for capacity.
- **M is trained on set.mm and only works on set.mm.** It scores set.mm labels against set.mm goals. It cannot be transplanted into Ascent2, which has a different language.
- **Random splits leak mildly.** A held-out early theorem may be cited by a training-set later one. Use `--split chrono` if you want the strict version.
- **Nothing here changes ‖·‖.** M reorders; it does not shorten proofs. It buys the gap between "a short proof exists" and "search finds it", which is large — and is not the gap the Clay problems sit in.
