# Setup

```bash
git clone <your-repo-url> arach1
cd arach1
pip install -r requirements.txt
```

Then fetch the database (51 MB, deliberately not committed):

```bash
curl -L -o set.mm https://raw.githubusercontent.com/metamath/set.mm/develop/set.mm
```

or download it from <https://github.com/metamath/set.mm> and drop `set.mm`
beside `run.py`.

Verify everything is wired up:

```bash
python run.py --quick
```

That runs the whole pipeline small — preflight, prep 1500 theorems, 3
resamples, a 3-per-band benchmark — in roughly two minutes. If it finishes
with a table, you are ready for the real run:

```bash
python run.py
```
