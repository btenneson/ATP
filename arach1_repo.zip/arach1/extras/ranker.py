#!/usr/bin/env python3
r"""
ranker.py -- M, a search policy for Predator, trained on set.mm.

M is a pairwise-logistic ranker over hand-built features.  It is deliberately
the SIMPLEST thing that could work, for the reason established twice already
in this codebase: a heuristic here was once slower than nothing, and its
replacement was silently inert because it keyed on a feature that returned
bound-variable names.  Both would have looked like success to a neural model
trained on the same signal.  So the ordering is: features first, measured
against the frequency prior, and only then something with more capacity.

WHAT M IS FOR
-------------
Not proving theorems.  Collapsing the effective branching factor.  A
breadth-first search touches ~b^d nodes; on set.mm the measured median
candidate pool is b = 4735, so d = 6 is ~1e22.  Get the right assertion into
the top 20 and that becomes 6.4e7; into the top 5 and it is 1.6e4.  M's job
is to move the true rule up the list.  Depth then becomes affordable.

THE INTERFACE PREDATOR ALREADY HAS
----------------------------------
predator71.prove() takes a `rank` argument that no caller has ever passed:

    sc_c = rank(gt, closers) if rank else [0.0] * len(closers)
    sc_o = rank(gt, openers) if rank else [0.0] * len(openers)
    pick = (closers sorted by -sc_c) + (openers sorted by -sc_o)[:48]

Note the 48.  Openers are CAPPED, so without a ranker Predator keeps an
arbitrary 48 of several thousand.  That cap is the single place a policy pays
off most: the same 48 slots, filled by score instead of by database order.

    python ranker.py --train           # fit and evaluate against the prior
    python ranker.py --eval-only       # reload and score the test split

Brian Tenneson.  Implementation by Claude (Anthropic).
"""
from __future__ import annotations
import argparse, json, math, os, pickle, sys, time
from collections import Counter

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.setrecursionlimit(100000)

FEATS = ["log_freq", "jaccard", "cover_goal", "len_ratio",
         "abs_len_diff", "n_ehyp", "is_closer", "depth_pos", "bias"]


def featurise(goal_toks, concl_toks, lab, freq, pos, nlab, n_e):
    """Feature vector for (goal, candidate).  Everything here must be cheap:
    it is evaluated once per candidate per expansion inside the search."""
    g = set(goal_toks)
    c = set(concl_toks)
    inter = len(g & c)
    union = len(g | c) or 1
    lg = len(goal_toks) or 1
    lc = len(concl_toks) or 1
    return [
        math.log1p(freq.get(lab, 0)),          # how often it is used at all
        inter / union,                          # token Jaccard
        inter / len(g) if g else 0.0,           # fraction of goal covered
        lc / lg,                                # relative size
        abs(lc - lg) / max(lc, lg),             # size mismatch
        n_e,                                    # number of $e hypotheses
        1.0 if n_e == 0 else 0.0,               # closes the goal outright
        pos.get(lab, 0) / max(nlab, 1),         # how late in the database
        1.0,
    ]


def load_split(path, freq, pos, meta, nlab, cap=None):
    """Returns X_pos, X_neg arrays of matched shape."""
    P, N = [], []
    for i, line in enumerate(open(path)):
        if cap and i >= cap:
            break
        s = json.loads(line)
        gt = s["goal"].split()
        m = meta.get(s["rule"])
        if m is None:
            continue
        fp = featurise(gt, m[0], s["rule"], freq, pos, nlab, m[1])
        for neg in s["negatives"]:
            mn = meta.get(neg)
            if mn is None:
                continue
            P.append(fp)
            N.append(featurise(gt, mn[0], neg, freq, pos, nlab, mn[1]))
    return np.array(P, dtype=float), np.array(N, dtype=float)


def fit(Xp, Xn, epochs=4000, lr=1.0, l2=1e-6, seed=0):
    """Pairwise logistic: maximise sigma(w.(f_pos - f_neg)).

    NB the standardisation is computed on the RAW features and the difference
    is then only SCALED, never centred.  Centring the difference vector was
    the first version of this function and it destroyed the entire signal:
    the mean of Xp - Xn is precisely what distinguishes a chosen rule from an
    unchosen one, so subtracting it left near-noise.  Train pairwise accuracy
    was 57.8% and the resulting policy scored 0.9% top-1 against a 59.7%
    frequency prior -- worse than random, from a one-line modelling error."""
    rng = np.random.default_rng(seed)
    A = np.vstack([Xp, Xn])
    mu, sd = A.mean(0), A.std(0) + 1e-9
    Dn = (Xp - Xn) / sd                     # scale only, no centring
    n, d = Dn.shape
    w = rng.normal(0, 0.01, d)
    for _ in range(epochs):
        z = np.clip(Dn @ w, -30, 30)
        p = 1.0 / (1.0 + np.exp(-z))
        grad = Dn.T @ (p - 1.0) / n + l2 * w
        w -= lr * grad
    acc = float((Dn @ w > 0).mean())
    return w, mu, sd, acc


def score_matrix(X, w, mu, sd):
    return ((X - mu) / sd) @ w


def evaluate(path, freq, pos, meta, nlab, model, cap=None):
    w, mu, sd = model
    top1 = top5 = tot = 0
    base1 = 0
    for i, line in enumerate(open(path)):
        if cap and i >= cap:
            break
        s = json.loads(line)
        gt = s["goal"].split()
        cands = [s["rule"]] + s["negatives"]
        rows, keep = [], []
        for c in cands:
            m = meta.get(c)
            if m is None:
                continue
            rows.append(featurise(gt, m[0], c, freq, pos, nlab, m[1]))
            keep.append(c)
        if s["rule"] not in keep:
            continue
        tot += 1
        sc = score_matrix(np.array(rows, dtype=float), w, mu, sd)
        order = [keep[j] for j in np.argsort(-sc)]
        if order[0] == s["rule"]:
            top1 += 1
        if s["rule"] in order[:5]:
            top5 += 1
        # frequency prior, same candidate set
        if max(keep, key=lambda c: freq.get(c, 0)) == s["rule"]:
            base1 += 1
    return tot, top1, top5, base1


# ---------------------------------------------------------------------------
def make_rank(model, freq, pos, meta, nlab):
    """A callable with predator71.prove()'s `rank` signature.

        rank(goal_tree, candidates) -> list[float]

    candidates are (label, conclusion_tree, data) triples, data[3] being the
    conclusion token list."""
    w, mu, sd = model

    def rank(gt, cands):
        if not cands:
            return []
        gtoks = gt.tokens()
        rows = []
        for lab, _tree, data in cands:
            concl = data[3][1:] if data[3] and data[3][0] == "|-" else data[3]
            rows.append(featurise(gtoks, concl, lab, freq, pos, nlab,
                                  len(data[2])))
        return list(score_matrix(np.array(rows, dtype=float), w, mu, sd))
    return rank


def build_tables(mm):
    """freq comes from the TRAIN split only -- deriving it from the whole
    database would leak test theorems into the policy."""
    pos = {l: i for i, l in enumerate(mm.order)}
    meta = {}
    for lab in mm.order:
        typ, data = mm.labels[lab]
        if typ not in ("$a", "$p"):
            continue
        concl = data[3]
        if not concl or concl[0] != "|-":
            continue
        meta[lab] = (concl[1:], len(data[2]))
    return pos, meta, len(mm.order)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", default="/tmp/pairs")
    ap.add_argument("--cache", default="/tmp/setmm.pkl")
    ap.add_argument("--model", default="/tmp/ranker.pkl")
    ap.add_argument("--cap", type=int, default=12000)
    ap.add_argument("--eval-only", action="store_true")
    a = ap.parse_args()

    print("=" * 74)
    print("  M -- a search policy for Predator, trained on set.mm")
    print("=" * 74)

    with open(a.cache, "rb") as f:
        mm = pickle.load(f)
    pos, meta, nlab = build_tables(mm)

    tr_path = os.path.join(a.pairs, "train.jsonl")
    freq = Counter(json.loads(l)["rule"] for l in open(tr_path))
    print("\n  %s labels with a |- conclusion, %s distinct rules in train"
          % (f"{len(meta):,}", f"{len(freq):,}"))

    if a.eval_only and os.path.exists(a.model):
        with open(a.model, "rb") as f:
            w, mu, sd = pickle.load(f)
    else:
        t0 = time.time()
        Xp, Xn = load_split(tr_path, freq, pos, meta, nlab, cap=a.cap)
        print("  training on %s pairs (%d features)" % (f"{len(Xp):,}",
                                                        Xp.shape[1]))
        w, mu, sd, acc = fit(Xp, Xn)
        print("  fit in %.1fs, train pairwise accuracy %.1f%%"
              % (time.time() - t0, 100 * acc))
        with open(a.model, "wb") as f:
            pickle.dump((w, mu, sd), f)

    print("\n  learned weights")
    for nm, wt in sorted(zip(FEATS, w), key=lambda z: -abs(z[1])):
        print("    %-12s %+7.3f" % (nm, wt))

    for split in ("valid", "test"):
        p = os.path.join(a.pairs, "%s.jsonl" % split)
        if not os.path.exists(p):
            continue
        tot, t1, t5, b1 = evaluate(p, freq, pos, meta, nlab, (w, mu, sd),
                                   cap=a.cap)
        print("\n  %s  (%s steps, 1 positive vs head-matched negatives)"
              % (split, f"{tot:,}"))
        print("    frequency prior   top-1  %5.1f%%" % (100 * b1 / tot))
        print("    M                 top-1  %5.1f%%   top-5  %5.1f%%"
              % (100 * t1 / tot, 100 * t5 / tot))
        print("    delta             top-1  %+5.1f pts"
              % (100 * (t1 - b1) / tot))
    print("\n  model written to %s" % a.model)
    return 0


if __name__ == "__main__":
    sys.exit(main())
