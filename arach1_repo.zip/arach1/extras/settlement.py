#!/usr/bin/env python3
r"""
settlement.py -- the measurement protocol of Problem 13.1, instrumented.

Implements the settlement machine M-tensor over Predator_7.1's search:

    1. ONE shared index, built once.
    2. TWO goal stacks alternating on expansion -- odd stages to c, even to
       ~c (Definition 9.4, sigma = first stage either side closes).
    3. CROSS-BRANCH INSERTION (Definition 9.7): when a branch closes a
       subgoal and the closed instance is GROUND, the nullary derived rule
       d_lambda is adjoined to the shared index as a new closer, available
       to both branches thereafter.
    4. ORIGIN AND USE LOGGING, giving kappa^av_m and kappa^us_m of
       Definition 9.6 as ratios of counters.

Remark 13.2 is respected: the branches share the LEMMA store only.  Their
substitutions are separate objects and are never unified across the divide.
Sharing substitutions would be unsound and the CV would rightly reject the
result.

WHAT COUNTS AS WHAT
-------------------
lambda is available-crossed once it is returned by candidates() to a goal
of the branch that did not close it.  Predator buckets closers by
conclusion head, so availability is exactly head-match reachability.

lambda is use-crossed once the other branch successfully unifies it with a
goal and pushes the resulting node -- a step actually taken, per Def 9.6.

DIVIDEND
--------
--mode sep removes the shared store, giving M_sep.  Delta(c) = sigma_sep -
sigma_tensor is the settlement dividend of Theorem 11.1(iii), which the
theory ties to kappa^us: kappa^us = 0 implies Delta(c) = 0.

    python settlement.py --stages 40000
    python settlement.py --stages 40000 --mode sep

Brian Tenneson.  Instrumentation by Claude (Anthropic).
"""
from __future__ import annotations
import argparse, csv, heapq, itertools, json, os, sys, time
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.setrecursionlimit(20000)

from metamath import MM, Toks, MMError                      # noqa: E402
import setmm_grammar as G                                    # noqa: E402
import predator71 as P                                       # noqa: E402
from named_ladder import BASE                                # noqa: E402


# ---------------------------------------------------------------------------
def is_ground(t, sub):
    """No variables of any kind survive -- neither assertion variables nor
    metavariables.  Definition 9.7 inserts only ground lemmas."""
    t = P.walk(t, sub)
    if t.var is not None:
        return False
    return all(is_ground(k, sub) for k in t.kids)


class SharedIndex:
    """Predator's Index, plus cross-branch insertion and access logging."""

    def __init__(self, mm, by_tc, share=True):
        base = P.Index(mm, by_tc)
        self.by_tc = by_tc
        self.closers = {k: list(v) for k, v in base.closers.items()}
        self.openers = {k: list(v) for k, v in base.openers.items()}
        self.n_base = base.n
        self.share = share

        self.lemmas = {}          # key -> dict(origin, stage, head, tokens)
        self.avail_crossed = set()
        self.use_crossed = set()
        self.lemma_of_label = {}  # synthetic label -> key
        self._seq = itertools.count(1)
        self.closed_events = 0

    # -- insertion ---------------------------------------------------------
    def insert(self, tree, origin, stage):
        key = " ".join(tree.tokens())
        self.closed_events += 1
        if key in self.lemmas:
            return False
        lab = "d%d" % next(self._seq)
        head = None if tree.var is not None else tree.label
        # a ground lemma has no mandatory hypotheses of either kind
        data = (frozenset(), [], [], ["|-"] + list(tree.tokens()))
        self.lemmas[key] = dict(origin=origin, stage=stage, head=head,
                                label=lab, tokens=key)
        self.lemma_of_label[lab] = key
        if self.share:
            self.closers.setdefault(head, []).append((lab, tree, data))
        return True

    # -- access ------------------------------------------------------------
    def candidates(self, goal, branch=None):
        def grab(d):
            if goal.var is not None:
                return [x for b in d.values() for x in b]
            return d.get(goal.label, []) + d.get(None, [])
        cl, op = grab(self.closers), grab(self.openers)
        if branch is not None:
            for lab, _t, _d in cl:
                key = self.lemma_of_label.get(lab)
                if key and self.lemmas[key]["origin"] != branch:
                    self.avail_crossed.add(key)
        return cl, op

    def note_use(self, lab, branch):
        key = self.lemma_of_label.get(lab)
        if key and self.lemmas[key]["origin"] != branch:
            self.use_crossed.add(key)

    # -- kappa -------------------------------------------------------------
    def kappa(self):
        n = len(self.lemmas)
        if n == 0:
            return 0.0, 0.0, 0
        return (len(self.avail_crossed) / n,
                len(self.use_crossed) / n, n)


class Branch:
    """One goal stack.  Mirrors prove()'s state, one expansion at a time."""

    def __init__(self, name, goal_tree):
        self.name = name
        self.frontier = [(0.0, 0, P.Node([(goal_tree, None, 0)], {}, (), 0))]
        self.seen = set()
        self.tie = 0
        self.exp = 0
        self.halted_at = None
        self.result = None

    def step(self, index, max_depth, max_open, stage):
        """One expansion.  Returns list of ground lemmas closed this step."""
        if not self.frontier or self.halted_at is not None:
            return []
        _, _, node = heapq.heappop(self.frontier)
        self.exp += 1
        if not node.goals:
            self.halted_at = stage
            root = None
            for parent, ix, st in node.trail:
                if parent is None:
                    root = st
                else:
                    parent.subs[ix] = st
            self.result = (root, node.sub)
            return []
        if node.depth >= max_depth or len(node.goals) > max_open:
            return []

        gi = P.pick_goal(node.goals, node.sub)
        gt, slot, hix = node.goals[gi]
        rest = node.goals[:gi] + node.goals[gi + 1:]
        gt = P.apply_sub(gt, node.sub)

        key = (node.depth, " ".join(gt.tokens()),
               tuple(sorted(" ".join(P.apply_sub(g, node.sub).tokens())
                            for g, _, _ in rest)))
        if key in self.seen:
            return []
        self.seen.add(key)

        closers, openers = index.candidates(gt, branch=self.name)
        pick = closers + openers[:48]
        closed = []

        for lab, ct, data in pick:
            m = {}
            c2 = P.rename_apart(ct, m)
            s2 = P.unify(c2, gt, node.sub)
            if s2 is None:
                continue
            index.note_use(lab, self.name)
            _, f_hyps, e_hyps, _ = data
            fmap = {var: m.get(var, P.fresh(tc)) for _, tc, var in f_hyps}
            for _, tc, var in f_hyps:
                m.setdefault(var, fmap[var])
            step = P.Step(lab, fmap, data)
            newgoals, ok = [], True
            for hj, (_, stat) in enumerate(e_hyps):
                try:
                    ht = G.parse(stat[1:], "wff", index.by_tc)
                except (RecursionError, MMError):
                    ht = None
                if ht is None:
                    ok = False
                    break
                newgoals.append((P.rename_apart(ht, m), step, hj))
            if not ok:
                continue

            # Definition 9.7: a subgoal closed to a GROUND instance is a
            # theorem, and becomes a nullary derived rule.
            if not e_hyps and is_ground(gt, s2):
                closed.append(P.apply_sub(gt, s2))

            self.tie += 1
            heapq.heappush(self.frontier,
                           (node.depth + 1 - 0.0, self.tie,
                            P.Node(newgoals + rest, s2,
                                   node.trail + ((slot, hix, step),),
                                   node.depth + 1)))
        return closed


def settle(mm, by_tc, c_text, stages, max_depth, max_open, share, trace):
    gt_pos = G.parse(c_text.split(), "wff", by_tc)
    gt_neg = G.parse(("-. " + c_text).split(), "wff", by_tc)
    if gt_pos is None or gt_neg is None:
        return None
    index = SharedIndex(mm, by_tc, share=share)
    A = Branch("A", gt_pos)
    B = Branch("B", gt_neg)
    traj = []
    sigma = None
    t0 = time.perf_counter()

    for stage in range(1, stages + 1):
        br = A if stage % 2 == 1 else B
        for lem in br.step(index, max_depth, max_open, stage):
            index.insert(lem, br.name, stage)
        if A.halted_at or B.halted_at:
            sigma = stage
            break
        if trace and stage % trace == 0:
            av, us, n = index.kappa()
            traj.append(dict(stage=stage, lemmas=n,
                             avail_crossed=len(index.avail_crossed),
                             use_crossed=len(index.use_crossed),
                             kappa_av=round(av, 6), kappa_us=round(us, 6),
                             expA=A.exp, expB=B.exp))
        if not A.frontier and not B.frontier:
            break

    av, us, n = index.kappa()
    return dict(conjecture=c_text, share=share, sigma=sigma,
                stages_run=min(stage, stages),
                halted=("A" if A.halted_at else ("B" if B.halted_at else None)),
                lemmas=n, closure_events=index.closed_events,
                avail_crossed=len(index.avail_crossed),
                use_crossed=len(index.use_crossed),
                kappa_av=round(av, 6), kappa_us=round(us, 6),
                expA=A.exp, expB=B.exp,
                seconds=round(time.perf_counter() - t0, 2),
                trajectory=traj)


# conjectures c for which ~c is a theorem of ax-1/ax-2/ax-3, so branch B is
# the one that can halt.  Each is the negation of a tautology.
CONJECTURES = [
    "-. ( ph -> ph )",
    "-. ( ph -> ( ps -> ph ) )",
    "-. ( -. ph -> ( ph -> ps ) )",
    "( ph -> -. ph )",
    "( -. ph -> ph )",
    "-. ( ( ph -> ps ) -> ( ( ch -> ph ) -> ( ch -> ps ) ) )",
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", type=int, default=40000)
    ap.add_argument("--max-depth", type=int, default=10)
    ap.add_argument("--max-open", type=int, default=6)
    ap.add_argument("--mode", choices=["tensor", "sep", "both"],
                    default="both")
    ap.add_argument("--trace", type=int, default=2000)
    ap.add_argument("--out", default="results_kappa")
    ap.add_argument("--only", type=int, default=None,
                    help="index into CONJECTURES")
    a = ap.parse_args()

    mm = MM()
    mm.read(Toks(BASE))
    by_tc = G.build_grammar(mm)

    todo = CONJECTURES if a.only is None else [CONJECTURES[a.only]]
    modes = ([True] if a.mode == "tensor" else
             [False] if a.mode == "sep" else [True, False])

    print("=" * 78)
    print("  Problem 13.1 -- kappa^us for Predator_7.1's policy")
    print("=" * 78)
    print("  %-42s %-6s %7s %7s %8s %8s"
          % ("conjecture c", "share", "|Lam|", "used", "kap_av", "kap_us"))
    print("  " + "-" * 74)

    rows = []
    for c in todo:
        for share in modes:
            r = settle(mm, by_tc, c, a.stages, a.max_depth, a.max_open,
                       share, a.trace)
            if r is None:
                print("  %-42s DOES NOT PARSE" % c[:42])
                continue
            rows.append(r)
            print("  %-42s %-6s %7s %7s %8.4f %8.4f"
                  % (c[:42], "yes" if share else "no",
                     f"{r['lemmas']:,}", f"{r['use_crossed']:,}",
                     r["kappa_av"], r["kappa_us"]))

    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "kappa.json"), "w") as f:
        json.dump(rows, f, indent=2)
    flat = [{k: v for k, v in r.items() if k != "trajectory"} for r in rows]
    if flat:
        with open(os.path.join(a.out, "kappa.csv"), "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(flat[0].keys()))
            w.writeheader()
            w.writerows(flat)

    tens = [r for r in rows if r["share"]]
    if tens:
        us = [r["kappa_us"] for r in tens]
        av = [r["kappa_av"] for r in tens]
        print("\n  kappa^us over %d conjectures: min %.4f  max %.4f"
              % (len(us), min(us), max(us)))
        print("  kappa^av over %d conjectures: min %.4f  max %.4f"
              % (len(av), min(av), max(av)))
    print("  wrote %s/kappa.json" % a.out)
    return 0


if __name__ == "__main__":
    sys.exit(P._big_stack(main) or 0)
