#!/usr/bin/env python3
r"""
Predator_7.1 -- a prover for set.mm.  Unification, metavariables, checked proofs.
Brian Tenneson.

    python predator71.py selftest                    no files needed
    python predator71.py prove set.mm --label prcom  attempt a proof
    python predator71.py verify prcom_p71.mm         check it independently

WHAT CHANGED FROM 7.0, AND WHY
------------------------------
7.0 searched by MATCHING: the goal was ground, the assertion's conclusion held
the variables, and the match was one-way.  That works only for assertions whose
hypothesis variables all occur in their conclusion.

ax-mp fails that test.  Its conclusion is the bare variable `ps`, so matching it
against a goal binds ps and leaves `ph` -- the entire antecedent -- with no
value.  syl fails the same way.  Those are the two most-used logical labels in
set.mm, and 864 of 4,643 assertions before prcom were excluded with them.

7.1 replaces matching with UNIFICATION over two variable namespaces:

    assertion variables   ph, ps, A, B ...   renamed apart at each use
    metavariables         ?1, ?2, ...        stand for not-yet-known subterms

Applying ax-mp to goal G binds ps := G and leaves ph unknown, so ph becomes a
metavariable ?1 and the second subgoal is  ( ?1 -> G ).  That subgoal is NOT
unconstrained: its consequent is fixed, so only assertions concluding something
of the form ( _ -> G ) can match, and whichever one does determines ?1.

That is the whole idea.  A free metavariable is harmless as long as a later step
determines it; what matters is that no step is required to INVENT a formula out
of nothing.

PROOFS ARE EMITTED AND CHECKED
------------------------------
A parse tree is a Metamath syntax proof: a node with rule L and children k1..kn
serialises in RPN as  proof(k1) ... proof(kn) L.  So the 95% of set.mm proof
steps that are formula construction are GENERATED from the tree rather than
searched for.

A logical step applying assertion A under substitution sigma emits

    [ trees for A's mandatory $f hypotheses, under sigma ]
    [ recursive proofs of A's $e hypotheses ]
    A

which is exactly what the verifier consumes.  `prove` writes a .mm file;
nothing here reports its own success.

WHAT IS STILL NOT DONE
----------------------
Disjoint-variable conditions are checked by the verifier but are not used to
PRUNE the search, so 7.1 can spend effort on branches the verifier will later
reject.  Any proof it emits is still sound -- the verifier is the authority --
but the search is not as sharp as it could be.
"""
from __future__ import annotations
import argparse, heapq, itertools, os, sys, time
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from metamath import MM, Toks, load, MMError
    import setmm_grammar as G
except ImportError as e:
    raise SystemExit("predator71.py needs metamath.py and setmm_grammar.py "
                     "in the same folder (%s)" % e)

VERSION = "7.1"
# NB: this used to chdir into a hard-coded absolute path when that folder
# happened to exist, which silently broke every relative path for callers
# that import predator71 as a library.  Opt in with PREDATOR_WORKDIR instead.
WORKDIR = os.environ.get("PREDATOR_WORKDIR", "")
if WORKDIR and os.path.isdir(WORKDIR):
    os.chdir(WORKDIR)
sys.setrecursionlimit(8000)


# ===========================================================================
#  trees with two flexible namespaces
# ===========================================================================
_counter = itertools.count(1)


def fresh(tc):
    """A new metavariable of the given typecode."""
    return G.Tree(None, tc, (), "?%d" % next(_counter))


def is_meta(t):
    return t.var is not None and t.var.startswith("?")


def rename_apart(t, mapping):
    """Fresh metavariables for an assertion's own variables.

    Without this, two uses of the same assertion in one proof would share
    variable names and unify with each other by accident."""
    if t.var is not None:
        if t.var not in mapping:
            mapping[t.var] = fresh(t.typecode)
        return mapping[t.var]
    return G.Tree(t.label, t.typecode, [rename_apart(k, mapping) for k in t.kids])


def walk(t, sub):
    while is_meta(t) and t.var in sub:
        t = sub[t.var]
    return t


def apply_sub(t, sub):
    t = walk(t, sub)
    if t.var is not None:
        return t
    return G.Tree(t.label, t.typecode, [apply_sub(k, sub) for k in t.kids])


def occurs(v, t, sub):
    t = walk(t, sub)
    if t.var is not None:
        return t.var == v
    return any(occurs(v, k, sub) for k in t.kids)


def unify(a, b, sub):
    """Robinson unification over metavariables, with occurs check.

    Only metavariables are flexible.  A statement's ordinary variables have
    already been renamed to metavariables by rename_apart, so everything
    flexible is a metavariable and everything else is rigid."""
    a, b = walk(a, sub), walk(b, sub)
    if a is b:
        return sub
    if is_meta(a):
        if is_meta(b) and a.var == b.var:
            return sub
        if a.typecode != b.typecode:
            return None
        if occurs(a.var, b, sub):
            return None
        s = dict(sub); s[a.var] = b; return s
    if is_meta(b):
        return unify(b, a, sub)
    if a.var is not None or b.var is not None:
        return sub if (a.var == b.var and a.typecode == b.typecode) else None
    if a.label != b.label or len(a.kids) != len(b.kids):
        return None
    for x, y in zip(a.kids, b.kids):
        sub = unify(x, y, sub)
        if sub is None:
            return None
    return sub


def ground(t, sub, fallback):
    """Instantiate any surviving metavariable.

    A metavariable never determined by the search is genuinely unconstrained --
    any well-formed term of its typecode makes the proof valid -- so it is
    filled with a declared variable.  set.mm statements are schematic, so this
    keeps the emitted proof well formed."""
    t = walk(t, sub)
    if t.var is not None:
        return fallback[t.typecode] if is_meta(t) else t
    return G.Tree(t.label, t.typecode, [ground(k, sub, fallback) for k in t.kids])


# ===========================================================================
#  emitting Metamath proofs
# ===========================================================================
def tree_proof(t, fvar):
    """RPN for a parse tree: children first, then the rule label.

    This is the formula-construction majority of a set.mm proof, produced by
    walking a tree instead of searching for it."""
    if t.var is not None:
        if t.var not in fvar:
            raise MMError("no $f hypothesis for variable %s" % t.var)
        return [fvar[t.var]]
    out = []
    for k in t.kids:
        out.extend(tree_proof(k, fvar))
    out.append(t.label)
    return out


class Step:
    __slots__ = ("label", "fmap", "subs", "data")

    def __init__(self, label, fmap, data):
        self.label, self.fmap, self.data = label, fmap, data
        # One slot per $e hypothesis, filled BY INDEX.  Appending in the order
        # subgoals happen to be solved is wrong once the search picks the most
        # constrained goal first rather than the leftmost: emit() must lay the
        # hypotheses out in declaration order or the verifier reports a
        # hypothesis mismatch.
        self.subs = [None] * len(data[2])

    def emit(self, sub, fvar, fallback):
        _, f_hyps, e_hyps, _ = self.data
        out = []
        for _, tc, var in f_hyps:
            t = self.fmap.get(var)
            if t is None:
                raise MMError("%s: unbound %s" % (self.label, var))
            out.extend(tree_proof(ground(t, sub, fallback), fvar))
        for i, s in enumerate(self.subs):
            if s is None:
                raise MMError("%s: hypothesis %d never solved" % (self.label, i))
            out.extend(s.emit(sub, fvar, fallback))
        out.append(self.label)
        return out


# ===========================================================================
#  the index
# ===========================================================================
class Index:
    """Assertions with their conclusion parsed, bucketed by conclusion head.

    Unlike 7.0 this excludes nothing: an assertion whose hypotheses mention
    variables absent from its conclusion is exactly the case metavariables
    exist to handle."""

    def __init__(self, mm, by_tc, upto=None, say=None):
        self.by_tc = by_tc
        self.closers = defaultdict(list)   # no $e hypotheses: end a branch
        self.openers = defaultdict(list)   # have $e hypotheses: extend it
        self.n = 0
        order = mm.order[:upto] if upto is not None else mm.order
        for lab in order:
            typ, data = mm.labels[lab]
            if typ not in ("$a", "$p"):
                continue
            concl = data[3]
            if not concl or concl[0] != "|-" or len(concl) < 2:
                continue
            try:
                t = G.parse(concl[1:], "wff", by_tc)
            except (RecursionError, MMError):
                t = None
            if t is None:
                continue
            self.n += 1
            head = None if t.var is not None else t.label
            # Split on whether the assertion has $e hypotheses.  One with none
            # that unifies CLOSES the goal outright -- it is a complete proof
            # in one step.  Those must never be missed to a candidate cap, and
            # there are few of them, so they are kept separate and always tried
            # in full.  axin1, falanfal and tbw-ax4 each need exactly one such
            # assertion (pm2.01, anidm, falim) and all three failed at 20,000
            # expansions because the cap took an arbitrary 48 of thousands.
            (self.closers if not data[2] else self.openers)[head].append(
                (lab, t, data))
        if say:
            nc = sum(len(v) for v in self.closers.values())
            say("    %s assertions indexed (%s close a goal outright)"
                % (f"{self.n:,}", f"{nc:,}"))

    def candidates(self, goal):
        """(closers, openers) that could unify with this goal.

        A conclusion headed by a rule can only meet a goal headed by the same
        rule.  A conclusion that is a bare variable -- ax-mp -- meets anything,
        and so does any goal that is itself a metavariable.

        Closers are returned separately because they are tried exhaustively:
        a closer that unifies finishes the branch, so skipping one loses a
        proof outright, whereas skipping an opener only loses a route."""
        def grab(d):
            if goal.var is not None:
                return [x for b in d.values() for x in b]
            return d.get(goal.label, []) + d.get(None, [])
        return grab(self.closers), grab(self.openers)


# ===========================================================================
#  the search
# ===========================================================================
class Node:
    __slots__ = ("goals", "sub", "trail", "depth")

    def __init__(self, goals, sub, trail, depth):
        self.goals, self.sub, self.trail, self.depth = goals, sub, trail, depth


def n_metas(t, sub, acc=None):
    """How many distinct metavariables survive in this goal."""
    if acc is None:
        acc = set()
    t = walk(t, sub)
    if t.var is not None:
        if is_meta(t):
            acc.add(t.var)
        return acc
    for k in t.kids:
        n_metas(k, sub, acc)
    return acc


def pick_goal(goals, sub):
    """Choose the MOST CONSTRAINED open goal, not simply the first.

    A goal that is a bare metavariable constrains nothing -- every assertion in
    the corpus unifies with it -- so expanding it is pure guessing.  Left to
    itself the search does exactly that: ax-mp turns goal G into ( ?1 -> G )
    with ?1 free, and ?1 can be attacked by ax-mp again, giving an infinite
    regress that breadth-first order explores forever.

    Deferring under-constrained goals lets a SIBLING goal bind their
    metavariables first.  This is the standard fix for backward modus ponens
    and it is what makes the difference between thrashing and terminating."""
    best, bi = None, 0
    for i, (g, slot, _hix) in enumerate(goals):
        gg = walk(g, sub)
        bare = 1 if (gg.var is not None and is_meta(gg)) else 0
        key = (bare, len(n_metas(gg, sub)), -gg.size())
        if best is None or key < best:
            best, bi = key, i
    return bi


def prove(goal_tree, index, budget, max_depth, rank=None, say=print,
          progress=2000, max_open=6):
    """Backward search with metavariables.

    A state is (open goals, substitution).  Expanding the first goal picks an
    assertion, unifies its renamed conclusion with the goal, and replaces the
    goal by that assertion's hypotheses under the resulting substitution.  Any
    variable of the assertion not determined by the unification survives as a
    metavariable in those subgoals, to be determined by a later step.

    The substitution is threaded through every open goal, so binding a
    metavariable in one branch constrains the others.  That is what stops the
    search inventing formulas."""
    start = Node([(goal_tree, None, 0)], {}, (), 0)
    frontier = [(0.0, 0, start)]
    exp = tie = 0
    seen = set()
    t0 = time.perf_counter()
    while frontier:
        _, _, node = heapq.heappop(frontier)
        exp += 1
        if exp > budget:
            return None, exp
        if progress and say and exp % progress == 0:
            say("      %s expansions, %d open goals, %.0fs"
                % (f"{exp:,}", len(node.goals), time.perf_counter() - t0))
        if not node.goals:
            root = None
            for parent, ix, st in node.trail:
                if parent is None:
                    root = st
                else:
                    parent.subs[ix] = st
            return (root, node.sub), exp
        if node.depth >= max_depth:
            continue

        if len(node.goals) > max_open:
            continue                      # too many speculative subgoals open
        gi = pick_goal(node.goals, node.sub)
        (gt, slot, hix) = node.goals[gi]
        rest = node.goals[:gi] + node.goals[gi + 1:]
        gt = apply_sub(gt, node.sub)

        key = (node.depth, " ".join(gt.tokens()),
               tuple(sorted(" ".join(apply_sub(g, node.sub).tokens())
                            for g, _, _ in rest)))
        if key in seen:
            continue
        seen.add(key)

        closers, openers = index.candidates(gt)
        # Every closer, then a capped slice of the openers.  Ordering by
        # subgoal count is not a heuristic preference -- a closer that unifies
        # IS a proof of this goal, so trying openers first would be searching
        # past the answer.
        sc_c = rank(gt, closers) if rank else [0.0] * len(closers)
        sc_o = rank(gt, openers) if rank else [0.0] * len(openers)
        pick = ([closers[i] for i in
                 sorted(range(len(closers)), key=lambda i: -sc_c[i])] +
                [openers[i] for i in
                 sorted(range(len(openers)), key=lambda i: -sc_o[i])][:48])
        scored_of = dict()

        for lab, ct, data in pick:
            m = {}
            c2 = rename_apart(ct, m)
            s2 = unify(c2, gt, node.sub)
            if s2 is None:
                continue
            _, f_hyps, e_hyps, _ = data
            fmap = {var: m.get(var, fresh(tc)) for _, tc, var in f_hyps}
            for _, tc, var in f_hyps:
                m.setdefault(var, fmap[var])
            step = Step(lab, fmap, data)
            newgoals = []
            ok = True
            for hj, (_, stat) in enumerate(e_hyps):
                try:
                    ht = G.parse(stat[1:], "wff", index.by_tc)
                except (RecursionError, MMError):
                    ht = None
                if ht is None:
                    ok = False; break
                newgoals.append((rename_apart(ht, m), step, hj))
            if not ok:
                continue
            tie += 1
            heapq.heappush(frontier,
                           (node.depth + 1 - 0.0, tie,
                            Node(newgoals + rest, s2,
                                 node.trail + ((slot, hix, step),),
                                 node.depth + 1)))
    return None, exp


# ===========================================================================
#  selftest
# ===========================================================================
SELFTEST = r"""
$c wff |- ( ) -> /\ $.
$v ph ps ch $.
wph $f wff ph $.
wps $f wff ps $.
wch $f wff ch $.
wi $a wff ( ph -> ps ) $.
wa $a wff ( ph /\ ps ) $.
ax1 $a |- ( ph -> ( ps -> ph ) ) $.
ax2 $a |- ( ( ph -> ( ps -> ch ) ) -> ( ( ph -> ps ) -> ( ph -> ch ) ) ) $.
${ mpmin $e |- ph $.
   mpmaj $e |- ( ph -> ps ) $.
   ax-mp $a |- ps $. $}
"""


def cmd_selftest(a):
    print("\n" + "=" * 74)
    print("  PREDATOR_7.1 v%s  --  selftest" % VERSION)
    print("=" * 74 + "\n")
    mm = MM(); mm.read(Toks(SELFTEST))
    by_tc = G.build_grammar(mm)
    fvar, fallback = {}, {}
    for lab in mm.order:
        typ, d = mm.labels[lab]
        if typ == "$f":
            fvar[d[1]] = lab
            fallback.setdefault(d[0], G.Tree(None, d[0], (), d[1]))

    idx = Index(mm, by_tc, say=lambda s: print("  " + s))
    print("  ax-mp is included: its conclusion is the bare variable `ps`,")
    print("  which 7.0 excluded as undetermined.\n")

    bad = 0

    # (1) the identity  |- ( ph -> ph ).  Its only route is two applications of
    #     ax-mp, which 7.0 could not use at all.
    goal_toks = "( ph -> ph )".split()
    gt = G.parse(goal_toks, "wff", by_tc)
    print("  [1] goal  |- %s" % " ".join(goal_toks))
    print("      route requires ax-mp twice; 7.0 could not attempt this")
    t0 = time.perf_counter()
    res, exp = prove(gt, idx, 20000, 8)
    dt = time.perf_counter() - t0
    if res is None:
        print("      NOT PROVED, %s expansions  <-- FAILED" % f"{exp:,}"); bad += 1
    else:
        root, sub = res
        proof = root.emit(sub, fvar, fallback)
        print("      proved: %s expansions, %.2fs, %d proof steps"
              % (f"{exp:,}", dt, len(proof)))
        src = SELFTEST + "\nchk $p |- %s $= %s $.\n" % (
            " ".join(goal_toks), " ".join(proof))
        m2 = MM()
        try:
            m2.read(Toks(src))
            r = m2.verify("chk")
            print("      metamath.py verify: %s" % r.upper())
            bad += (r != "ok")
        except MMError as e:
            print("      metamath.py verify: FAILED -- %s" % e); bad += 1

    print("\n  %s\n" % ("all checks passed" if not bad
                        else "%d CHECK(S) FAILED" % bad))
    return 0 if not bad else 1


# ===========================================================================
#  prove
# ===========================================================================
def cmd_easiest(a):
    """Rank set.mm theorems by LOGICAL proof length, shortest first.

    Raw proof length is 95% formula construction, so sorting by it ranks
    theorems by how verbose their notation is.  Counting only |- steps ranks
    them by how much reasoning they need, which is what a prover faces.

    A theorem needing one logical step is the easiest thing this program can
    be asked to do.  If it fails there, the problem is not the budget."""
    from metamath import classify
    print("\n" + "=" * 74)
    print("  EASIEST TARGETS  --  by logical proof length")
    print("=" * 74 + "\n")
    mm = load(a.file)
    kind = classify(mm)

    thms = [l for l in mm.order if mm.labels[l][0] == "$p"]
    if a.scan:
        thms = thms[:a.scan]
    print("\n  measuring %s proofs..." % f"{len(thms):,}")
    rows = []
    for i, lab in enumerate(thms, 1):
        try:
            proof = mm.decompress(lab, mm.proofs[lab])
        except (MMError, RecursionError, ValueError):
            continue
        if "?" in proof:
            continue
        n = sum(1 for st in proof if kind.get(st) == "logic")
        if 0 < n <= a.max_steps:
            rows.append((n, len(proof), lab))
        if a.progress and i % a.progress == 0:
            print("    %s/%s" % (f"{i:,}", f"{len(thms):,}"))

    rows.sort()
    print("\n  %s theorems need %d or fewer logical steps\n"
          % (f"{len(rows):,}", a.max_steps))
    print("  %-5s %-7s %-14s %s" % ("logic", "raw", "label", "statement"))
    print("  " + "-" * 68)
    for n, raw, lab in rows[:a.limit]:
        stat = " ".join(mm.labels[lab][1][3])
        print("  %-5d %-7d %-14s %s" % (n, raw, lab, stat[:40]))
    print("""
  The `logic` column is the number of reasoning steps; `raw` includes the
  formula construction.  Their ratio is the notation factor for that theorem.

  Start at the top.  A one-logical-step theorem is one assertion applied once,
  and if the search cannot find that, no budget will help.
""")
    return 0


def cmd_prove(a):
    print("\n" + "=" * 74)
    print("  PREDATOR_7.1 v%s  --  prove %s" % (VERSION, a.label))
    print("=" * 74 + "\n")
    mm = load(a.file)
    by_tc = G.build_grammar(mm)
    if a.label not in mm.labels:
        print("\n  %s not found\n" % a.label); return 1
    stat = mm.labels[a.label][1][3]
    print("\n  goal  %s" % " ".join(stat))

    fvar, fallback = {}, {}
    for lab in mm.order:
        typ, d = mm.labels[lab]
        if typ == "$f":
            fvar.setdefault(d[1], lab)
            fallback.setdefault(d[0], G.Tree(None, d[0], (), d[1]))

    cut = mm.order.index(a.label)
    print("\n  indexing assertions before %s (parses conclusions once)..." % a.label)
    t0 = time.perf_counter()
    idx = Index(mm, by_tc, upto=cut, say=lambda s: print("  " + s))
    print("    %.1fs" % (time.perf_counter() - t0))

    gt = G.parse(stat[1:], "wff", by_tc)
    if gt is None:
        print("\n  goal does not parse\n"); return 1

    print("\n  searching (budget %s, max depth %d)..."
          % (f"{a.budget:,}", a.max_depth))
    t0 = time.perf_counter()
    res, exp = prove(gt, idx, a.budget, a.max_depth)
    dt = time.perf_counter() - t0

    if res is None:
        print("\n  NOT PROVED.  %s expansions, %.1fs" % (f"{exp:,}", dt))
        print("""
  Separate the causes before tuning:
    * budget exhausted        -> raise --budget
    * proof deeper than limit -> raise --max-depth
    * no route through the indexed assertions at all
""")
        return 1

    root, sub = res
    try:
        proof = root.emit(sub, fvar, fallback)
    except MMError as e:
        print("\n  found a derivation but could not emit it: %s\n" % e)
        return 1

    print("\n  PROVED.  %s expansions, %.1fs, %s proof steps"
          % (f"{exp:,}", dt, f"{len(proof):,}"))
    out = a.out or ("%s_p71.mm" % a.label)
    with open(out, "w") as f:
        f.write("$( Predator_7.1 proof of %s $)\n" % a.label)
        f.write("$[ %s $]\n" % a.file)
        f.write("chk $p %s $= %s $.\n" % (" ".join(stat), " ".join(proof)))
    print("  wrote %s" % out)

    # Verify immediately, in process.  This is not self-reporting: it is the
    # CV's own stack machine, which knows nothing about how the proof was
    # found.  Writing the file and telling the user to check it is still the
    # primary claim; this just fails fast when the proof is wrong.
    print("\n  handing the certificate to the CV...")
    try:
        chk = MM()
        chk.labels = dict(mm.labels)
        chk.order = list(mm.order)
        chk.proofs = dict(mm.proofs)
        chk.constants, chk.variables = mm.constants, mm.variables
        chk.scope_dvs = dict(mm.scope_dvs)
        dvs, f_hyps, e_hyps, _ = mm.labels[a.label][1]
        chk.labels["__chk__"] = ("$p", (dvs, f_hyps, e_hyps, stat))
        chk.proofs["__chk__"] = proof
        chk.scope_dvs["__chk__"] = mm.scope_dvs.get(a.label, dvs)
        r = chk.verify("__chk__")
        print("  CV verdict: %s" % r.upper())
        if r != "ok":
            return 1
    except MMError as e:
        print("  CV verdict: FAILED -- %s" % e)
        return 1
    print("""
  This program's word is not evidence.  Check it:

      python metamath.py verify %s
""" % out)
    return 0


def main():
    ap = argparse.ArgumentParser(prog="predator71", description=__doc__,
            formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("selftest")
    e = sub.add_parser("easiest")
    e.add_argument("file", nargs="?", default="set.mm")
    e.add_argument("--max-steps", type=int, default=2,
                   help="keep theorems needing at most this many logical steps")
    e.add_argument("--scan", type=int, default=8000,
                   help="how many theorems to measure (0 = all)")
    e.add_argument("--limit", type=int, default=30)
    e.add_argument("--progress", type=int, default=2000)
    p = sub.add_parser("prove")
    p.add_argument("file", nargs="?", default="set.mm")
    p.add_argument("--label", required=True)
    p.add_argument("--budget", type=int, default=50000)
    p.add_argument("--max-depth", type=int, default=10)
    p.add_argument("--out", default=None)

    a = ap.parse_args()
    if a.cmd == "selftest":  sys.exit(cmd_selftest(a))
    elif a.cmd == "easiest": sys.exit(cmd_easiest(a))
    elif a.cmd == "prove":   sys.exit(cmd_prove(a))
    else:                    ap.print_help()


def _big_stack(fn):
    import threading
    try:
        threading.stack_size(256 * 1024 * 1024)
    except (ValueError, RuntimeError):
        pass
    box = {}

    def target():
        try:
            box["rc"] = fn()
        except SystemExit as e:
            box["rc"] = e.code
        except RecursionError:
            print("\n  RecursionError -- a term nested deeper than the stack.\n")
            box["rc"] = 2
    t = threading.Thread(target=target, daemon=True)
    t.start()
    try:
        while t.is_alive():
            t.join(0.2)
    except KeyboardInterrupt:
        print("\n  interrupted.\n")
        return 130
    return box.get("rc", 0)


if __name__ == "__main__":
    sys.exit(_big_stack(main) or 0)
