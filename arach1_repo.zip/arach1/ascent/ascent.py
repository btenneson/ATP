#!/usr/bin/env python3
r"""
ASCENT -- a parameterised, self-certifying ATP over arithmetic.

Built fresh.  Three integer knobs, each starting at 1, each monotone: turning
one up never loses a theorem and always costs more.  Like an encoder bitrate.

    -d  DEPTH     certificate-tree depth explored by the search
    -w  WITNESS   largest numeral tried when hunting an existential witness
    -r  REFLECT   how many rungs of the reflection ladder are climbed

d and w are independent search knobs; d buys structure, w buys arithmetic.
r is the self-awareness knob and touches neither.  That separation is not an
accident of the implementation, it is the point -- see PROPOSITION 2 below.

WHY tier(A) > 0, AND WHAT IT EQUALS
-----------------------------------
The language is arithmetic with unbounded quantifiers over N, so targets have
real arithmetical tier and `tier()` computes it syntactically: bounded
quantifiers are free, unbounded ones count alternations, and polarity is
tracked so that a quantifier in the antecedent of an implication counts as
its dual.

    tier(Ascent(d,w,r)) = d,   independently of w and r.

Each quantifier block costs exactly one certificate node to discharge --
`gen` for forall, `wit` for exists -- so a target with n blocks needs depth n
and no more.  Measured: Pi-0-3 and Sigma-0-3 first certified at exactly d=3,
Pi-0-4 at exactly d=4.  The default d=2 gives tier 2, which is the tier of
P vs NP; that is a fact about the flag, not about the prover's strength.

THE KERNEL, AND WHAT MAKES THIS SELF-CERTIFYING
-----------------------------------------------
Section KERNEL is a checker for the judgement  Gamma |- phi  by structural
recursion on a certificate.  It is the only trusted component, it is small
enough to read, it never searches, and it has no self-model: lev(kernel) = 0
and must stay 0.

The search is untrusted.  Nothing enters the lemma store until the kernel has
accepted a certificate for it.

The reflection rule is where self-certification and self-awareness become the
same mechanism:

    nec(C)  proves  Pr(<A>, <phi>)     provided the kernel accepts C : phi

So the machine's claim "I prove phi" is discharged by the very kernel that
checks everything else.  Pr is not stipulated at any rung; each rung carries
a certificate the kernel re-checks.  This is the paper's necessitation rule
made effective, with the CV discharging the side condition.

    theta_0     = ATP(<A>)
    theta_{k+1} = Pr(<A>, <theta_k>)          Level n  iff  A |- theta_{n-1}

PROPOSITION 1 (why a self-certifier does not stall at 2 or 3).
If A has kernel-checked necessitation and its kernel is sound, then
lev(A) = omega.  Proof: A |- theta_0 by the base certificate.  If A |- theta_k
with certificate C_k, the kernel accepts C_k, so nec(C_k) is a certificate of
theta_{k+1} and A |- theta_{k+1}.  Induction.  No rung is harder than the
last -- each costs exactly one kernel call on the previous certificate.

So the level distribution over self-certifying machines is BIMODAL, at
{0 or 1} and at omega.  There is no natural fixed point at 2 or near 2: a
machine either has the rule, in which case nothing stops it, or lacks it, in
which case it never gets past theta_0.  Finite lev > 1 is achievable ONLY by
imposing a resource bound, which is exactly what -r is.  That is the honest
justification for the parameter: r is not a tuning constant, it is the only
thing that can make lev finite and nontrivial.

PROPOSITION 2 (the knobs are independent).
lev(A) = r regardless of d and w; the set of arithmetical theorems proved is
a function of (d, w) and is independent of r.  Verified empirically by the
sweep in --grid.  Increasing self-awareness buys no theorems, and proving
more theorems raises no level.

DIRECTION OF DEPENDENCE
-----------------------
Verification grounds the self-model, never the reverse.  A machine that
trusted its own certificates because it had proved itself trustworthy would
be in the Loeb trap: from a reflection principle "if I prove phi then phi"
one derives phi outright, so such a machine is unsound or vacuous.  Here Pr
is primitive and reflection is never assumed -- the machine only ever reports
verifications that have already happened.

    python ascent.py --demo
    python ascent.py -d 3 -w 20 -r 5
    python ascent.py --grid

Brian Tenneson.  Implementation by Claude (Anthropic).
"""
from __future__ import annotations
import argparse, itertools, json, os, sys, time
from collections import defaultdict

sys.setrecursionlimit(100000)

# ===========================================================================
#                                 SYNTAX
# ===========================================================================
# Terms:    ('n', int) ('v', name) ('c', name)   -- numeral, variable, eigen
#           ('+', a, b) ('*', a, b) ('s', a)
# Formulas: ('=', a, b) ('<', a, b) ('<=', a, b)
#           ('not', p) ('and', p, q) ('or', p, q) ('imp', p, q)
#           ('all', x, p) ('ex', x, p)                  unbounded
#           ('allb', x, t, p) ('exb', x, t, p)          bounded by t
#           ('atp', nm) ('pr', nm, nm)                  reflection atoms


def tsub(t, x, v):
    k = t[0]
    if k == 'v':
        return v if t[1] == x else t
    if k in ('n', 'c'):
        return t
    if k == 's':
        return ('s', tsub(t[1], x, v))
    return (k, tsub(t[1], x, v), tsub(t[2], x, v))


def tvars(t, acc=None):
    """Variable names -- ('v', _) -- occurring in a term.  Eigenconstants
    ('c', _) live in a separate namespace and are never captured."""
    if acc is None:
        acc = set()
    if t[0] == 'v':
        acc.add(t[1])
    elif t[0] == 's':
        tvars(t[1], acc)
    elif t[0] in ('+', '*'):
        tvars(t[1], acc)
        tvars(t[2], acc)
    return acc


def fvars(p, bound=frozenset(), acc=None):
    """Free variable names of a formula."""
    if acc is None:
        acc = set()
    k = p[0]
    if k in ('=', '<', '<='):
        for nm in tvars(p[1]) | tvars(p[2]):
            if nm not in bound:
                acc.add(nm)
    elif k == 'not':
        fvars(p[1], bound, acc)
    elif k in ('and', 'or', 'imp'):
        fvars(p[1], bound, acc)
        fvars(p[2], bound, acc)
    elif k in ('all', 'ex'):
        fvars(p[2], bound | {p[1]}, acc)
    elif k in ('allb', 'exb'):
        for nm in tvars(p[2]):
            if nm not in bound:
                acc.add(nm)
        fvars(p[3], bound | {p[1]}, acc)
    return acc


def _rename(y, avoid):
    i = 0
    z = y
    while z in avoid:
        i += 1
        z = "%s#%d" % (y, i)
    return z


def sub(p, x, v):
    """Capture-avoiding substitution of the term v for the variable x.

    An earlier version was documented as "capture-avoiding only in the sense
    we need", on the reasoning that certificate terms are built from numerals
    and eigenconstants, and eigenconstants are a separate namespace from
    bound variables.  That reasoning is correct about the CALLERS and wrong
    as a property of the function: sub( Ay. x = y , x := y ) returned
    Ay. y = y, capturing the free y.  The `ind` rule does substitute a term
    containing a variable, so the guarantee should not rest on caller
    discipline.  Binders are now renamed apart when the incoming term would
    be captured."""
    k = p[0]
    if k in ('all', 'ex', 'allb', 'exb'):
        y = p[1]
        if y == x:
            return p                      # x is shadowed: nothing to do
        body = p[2] if k in ('all', 'ex') else p[3]
        if y in tvars(v):                 # would capture -- rename the binder
            z = _rename(y, tvars(v) | fvars(body) | {x})
            body = sub(body, y, ('v', z))
            y = z
        if k in ('all', 'ex'):
            return (k, y, sub(body, x, v))
        return (k, y, tsub(p[2], x, v), sub(body, x, v))
    if k in ('=', '<', '<='):
        return (k, tsub(p[1], x, v), tsub(p[2], x, v))
    if k == 'not':
        return ('not', sub(p[1], x, v))
    if k in ('and', 'or', 'imp'):
        return (k, sub(p[1], x, v), sub(p[2], x, v))
    return p                                   # atp / pr / bot are closed


def teval(t):
    """Value of a closed term, or None if it has variables/eigenconstants."""
    k = t[0]
    if k == 'n':
        return t[1]
    if k in ('v', 'c'):
        return None
    if k == 's':
        a = teval(t[1])
        return None if a is None else a + 1
    a, b = teval(t[1]), teval(t[2])
    if a is None or b is None:
        return None
    return a + b if k == '+' else a * b


def padd(a, b):
    r = dict(a)
    for m, c in b.items():
        r[m] = r.get(m, 0) + c
        if r[m] == 0:
            del r[m]
    return r


def pmul(a, b):
    r = {}
    for m1, c1 in a.items():
        for m2, c2 in b.items():
            m = tuple(sorted(m1 + m2))
            r[m] = r.get(m, 0) + c1 * c2
    return {m: c for m, c in r.items() if c != 0}


def pneg(a):
    return {m: -c for m, c in a.items()}


def poly(t):
    k = t[0]
    if k == 'n':
        return {(): t[1]} if t[1] else {}
    if k in ('v', 'c'):
        return {(t[1],): 1}
    if k == 's':
        return padd(poly(t[1]), {(): 1})
    if k == '+':
        return padd(poly(t[1]), poly(t[2]))
    return pmul(poly(t[1]), poly(t[2]))


def decide(p, fuel=10000):
    """Three-valued: True, False, or None (kernel refuses).

    Sound over N because every symbol ranges over N, so a polynomial whose
    coefficients are all non-negative is itself non-negative."""
    k = p[0]
    if k in ('=', '<', '<='):
        pa, pb = poly(p[1]), poly(p[2])
        if k == '=':
            if pa == pb:
                return True
            d = padd(pb, pneg(pa))
            if all(m == () for m in d):          # differ by a constant only
                return False
            return None
        d = padd(pb, pneg(pa))                   # d = rhs - lhs
        nonneg = all(c > 0 for m, c in d.items() if m != ())
        const = d.get((), 0)
        if k == '<':
            if nonneg and const > 0:
                return True
        elif nonneg and const >= 0:
            return True
        # Falsity is only claimed when the difference is a bare constant --
        # i.e. both sides are closed, or their symbolic parts cancel.  With a
        # symbolic remainder the sign is unknown and the honest answer is
        # None.  (ascent2.decide strengthens this using dominance.)
        if all(m == () for m in d):
            return (const > 0) if k == '<' else (const >= 0)
        return None
    if k == 'not':
        v = decide(p[1], fuel)
        return None if v is None else not v
    if k in ('and', 'or', 'imp'):
        a, b = decide(p[1], fuel), decide(p[2], fuel)
        if k == 'and':
            if a is False or b is False:
                return False
            return True if (a and b) else None
        if k == 'or':
            if a is True or b is True:
                return True
            return False if (a is False and b is False) else None
        if a is False or b is True:
            return True
        return False if (a is True and b is False) else None
    if k in ('allb', 'exb'):
        n = teval(p[2])
        if n is None or n > fuel:
            return None
        for i in range(n):
            v = decide(sub(p[3], p[1], ('n', i)), fuel)
            if v is None:
                return None
            if k == 'allb' and not v:
                return False
            if k == 'exb' and v:
                return True
        return k == 'allb'
    return None


def tsyms(t, acc):
    if t[0] in ('v', 'c'):
        acc.add(t[1])
    elif t[0] == 's':
        tsyms(t[1], acc)
    elif t[0] in ('+', '*'):
        tsyms(t[1], acc)
        tsyms(t[2], acc)
    return acc


def syms(p, acc=None):
    if acc is None:
        acc = set()
    k = p[0]
    if k in ('=', '<', '<='):
        tsyms(p[1], acc)
        tsyms(p[2], acc)
    elif k == 'not':
        syms(p[1], acc)
    elif k in ('and', 'or', 'imp'):
        syms(p[1], acc)
        syms(p[2], acc)
    elif k in ('all', 'ex'):
        syms(p[2], acc)
    elif k in ('allb', 'exb'):
        tsyms(p[2], acc)
        syms(p[3], acc)
    return acc


def occurs_sym(nm, p):
    return nm in syms(p)


def show(p):
    k = p[0]
    if k in ('=', '<', '<='):
        return "%s %s %s" % (showt(p[1]), k, showt(p[2]))
    if k == 'not':
        return "~%s" % show(p[1])
    if k in ('and', 'or', 'imp'):
        op = {'and': '&', 'or': '|', 'imp': '->'}[k]
        return "(%s %s %s)" % (show(p[1]), op, show(p[2]))
    if k == 'all':
        return "A%s.%s" % (p[1], show(p[2]))
    if k == 'ex':
        return "E%s.%s" % (p[1], show(p[2]))
    if k == 'allb':
        return "A%s<%s.%s" % (p[1], showt(p[2]), show(p[3]))
    if k == 'exb':
        return "E%s<%s.%s" % (p[1], showt(p[2]), show(p[3]))
    if k == 'atp':
        return "ATP(%s)" % p[1]
    return "Pr(%s,%s)" % (p[1], p[2])


def showt(t):
    k = t[0]
    if k == 'n':
        return str(t[1])
    if k in ('v', 'c'):
        return t[1]
    if k == 's':
        return "S%s" % showt(t[1])
    return "(%s%s%s)" % (showt(t[1]), k, showt(t[2]))


# ---------------------------------------------------------------------------
def _join(a, b):
    """Class of a conjunction or disjunction of classes a and b.

    Sigma-0-n and Pi-0-n are each closed under both connectives, so equal
    leads stay put and the higher level absorbs the lower.  MIXED leads at
    the same level do NOT stay put: Sigma-0-n op Pi-0-n lands in Delta-0-(n+1)
    and in neither Sigma-0-n nor Pi-0-n.  The previous version took the
    argument with the larger subscript and kept its lead, which reported
    (Ex.P) & (Ay.Q) as Sigma-0-1."""
    (na, la), (nb, lb) = a, b
    if na != nb:
        return a if na > nb else b
    if la == lb:
        return (na, la)
    if la == 'D':
        return (nb, lb)
    if lb == 'D':
        return (na, la)
    return (na + 1, 'D')


def tier(p):
    """Arithmetical tier: alternations of UNBOUNDED quantifiers.

    Returns (n, lead), lead in {'S','P','D'} for Sigma-0-n, Pi-0-n, Delta-0-n.
    Bounded quantifiers cost nothing, which is the standard convention and
    the reason the bounded forms are in the language at all.

    Polarity is tracked explicitly.  A quantifier in NEGATIVE position is
    the dual of the one written -- under a negation, or in the ANTECEDENT of
    an implication, since A -> B is ~A or B.  The previous version flipped
    the lead for `not` but treated `imp` as symmetric, and so reported
    (Ax.P) -> (Ex.Q) as Pi-0-1 when it is Sigma-0-1."""
    def go(q, pol):
        k = q[0]
        if k in ('all', 'ex'):
            eff = k if pol > 0 else ('ex' if k == 'all' else 'all')
            me = 'P' if eff == 'all' else 'S'
            n, lead = go(q[2], pol)
            if lead == 'D':
                return n + 1 if n else 1, me
            return (n, lead) if lead == me else (n + 1, me)
        if k == 'not':
            return go(q[1], -pol)
        if k == 'imp':
            return _join(go(q[1], -pol), go(q[2], pol))
        if k in ('and', 'or'):
            return _join(go(q[1], pol), go(q[2], pol))
        if k in ('allb', 'exb'):
            return go(q[3], pol)
        return 0, 'D'
    return go(p, 1)


def tier_name(p):
    n, lead = tier(p)
    if n == 0:
        return "D0-0"
    if lead == 'D':
        return "Del0-%d" % n
    return "%s0-%d" % ("Sig" if lead == 'S' else "Pi", n)


# ===========================================================================
#                                 KERNEL
# ===========================================================================
# The ONLY trusted component.  It searches for nothing, has no self-model,
# and never grows.  check(store, ctx, phi, cert) -> True | raises Reject.
#
# Certificates:
#   ('calc',)                 phi closed and Delta-0 and true
#   ('hyp', i)                phi is ctx[i]
#   ('lemma', name)           phi is store[name]
#   ('impI', C)               phi = (A->B); C proves B under ctx+[A]
#   ('impE', A, C1, C2)       C1: A->phi, C2: A
#   ('andI', C1, C2)          phi = (A&B)
#   ('andE', i, A_and_B, C)   phi is the i-th conjunct of A_and_B
#   ('gen', C)                phi = Ax.psi; C proves psi[x := fresh eigen]
#   ('inst', t, Ax_psi, C)    C: Ax.psi; phi = psi[x := t]
#   ('wit', t, C)             phi = Ex.psi; C proves psi[x := t]
#   ('allbI', [C_0..C_{n-1}]) phi = Ax<n.psi
#   ('exbI', i, C)            phi = Ex<n.psi; C proves psi[x := i]
#   ('ind', C0, Cs)           phi = Ax.psi; C0: psi[0], Cs: Ax.(psi->psi[Sx])
#   ('nec', C)                phi = Pr(<A>,<psi>); C proves psi   <-- the rule
# ===========================================================================
class Reject(Exception):
    pass


_eigen = itertools.count(1)


class Kernel:
    """Trusted checker.  `names` maps a formula-name constant to the formula
    it names -- the injective naming operator, held outside the logic."""

    def __init__(self, tag, names):
        self.tag = tag
        self.names = names
        self.calls = 0

    def check(self, store, ctx, phi, C):
        self.calls += 1
        if not isinstance(C, tuple) or not C:
            raise Reject("malformed certificate")
        k = C[0]

        if k == 'calc':
            # closed and Delta-0, decided by evaluation; or symbolic and
            # settled by polynomial normalisation over N.  Both are
            # computations, neither is a search.
            if decide(phi) is not True:
                raise Reject("calc: %s is not decided true" % show(phi))
            return True

        if k == 'hyp':
            if not (0 <= C[1] < len(ctx)) or ctx[C[1]] != phi:
                raise Reject("hyp: not in context")
            return True

        if k == 'lemma':
            if store.get(C[1]) != phi:
                raise Reject("lemma %s is not %s" % (C[1], show(phi)))
            return True

        if k == 'impI':
            if phi[0] != 'imp':
                raise Reject("impI: goal is not an implication")
            return self.check(store, ctx + [phi[1]], phi[2], C[1])

        if k == 'impE':
            A = C[1]
            self.check(store, ctx, ('imp', A, phi), C[2])
            return self.check(store, ctx, A, C[3])

        if k == 'andI':
            if phi[0] != 'and':
                raise Reject("andI: goal is not a conjunction")
            self.check(store, ctx, phi[1], C[1])
            return self.check(store, ctx, phi[2], C[2])

        if k == 'andE':
            i, conj = C[1], C[2]
            if conj[0] != 'and' or conj[1 + i] != phi:
                raise Reject("andE: projection mismatch")
            return self.check(store, ctx, conj, C[3])

        if k == 'gen':
            # ('gen', name, C).  The certificate names its own eigenconstant;
            # the kernel enforces the eigenvariable condition rather than
            # inventing a name of its own, which would never match what the
            # untrusted search put inside C.
            if phi[0] != 'all':
                raise Reject("gen: goal is not universal")
            nm = C[1]
            if occurs_sym(nm, phi) or any(occurs_sym(nm, h) for h in ctx) \
                    or any(occurs_sym(nm, f) for f in store.values()):
                raise Reject("gen: eigenvariable %s is not fresh" % nm)
            return self.check(store, ctx,
                              sub(phi[2], phi[1], ('c', nm)), C[2])

        if k == 'inst':
            t, univ = C[1], C[2]
            if univ[0] != 'all' or sub(univ[2], univ[1], t) != phi:
                raise Reject("inst: instance mismatch")
            return self.check(store, ctx, univ, C[3])

        if k == 'wit':
            if phi[0] != 'ex':
                raise Reject("wit: goal is not existential")
            return self.check(store, ctx, sub(phi[2], phi[1], C[1]), C[2])

        if k == 'allbI':
            if phi[0] != 'allb':
                raise Reject("allbI: goal is not bounded-universal")
            n = teval(phi[2])
            if n is None or n != len(C[1]):
                raise Reject("allbI: wrong number of instances")
            for i, Ci in enumerate(C[1]):
                self.check(store, ctx, sub(phi[3], phi[1], ('n', i)), Ci)
            return True

        if k == 'exbI':
            if phi[0] != 'exb':
                raise Reject("exbI: goal is not bounded-existential")
            n = teval(phi[2])
            if n is None or not (0 <= C[1] < n):
                raise Reject("exbI: index out of range")
            return self.check(store, ctx,
                              sub(phi[3], phi[1], ('n', C[1])), C[2])

        if k == 'ind':
            if phi[0] != 'all':
                raise Reject("ind: goal is not universal")
            x, psi = phi[1], phi[2]
            self.check(store, ctx, sub(psi, x, ('n', 0)), C[1])
            step = ('all', x, ('imp', psi, sub(psi, x, ('s', ('v', x)))))
            return self.check(store, ctx, step, C[2])

        if k == 'nec':
            # THE REFLECTION RULE.  Pr(<A>,<psi>) is accepted exactly when a
            # certificate of psi is accepted.  Self-certification and
            # self-awareness are the same kernel call.
            if phi[0] != 'pr' or phi[1] != self.tag:
                raise Reject("nec: goal is not Pr(<A>, -)")
            psi = self.names.get(phi[2])
            if psi is None:
                raise Reject("nec: %s names no formula" % phi[2])
            return self.check(store, [], psi, C[1])

        raise Reject("unknown certificate form %r" % (k,))


# ===========================================================================
#                                 SEARCH
# ===========================================================================
# Untrusted.  Parameterised by d (structural depth) and w (witness bound).
# Nothing it produces is believed until the kernel has checked it.
# ===========================================================================
class Search:
    def __init__(self, kernel, store, d, w):
        self.K = kernel
        self.store = store
        self.d = d
        self.w = w
        self.nodes = 0

    def prove(self, phi, depth=None, ctx=()):
        if depth is None:
            depth = self.d
        self.nodes += 1
        if depth < 0:
            return None
        ctx = tuple(ctx)

        # 0. decide it outright by evaluation or polynomial normalisation
        if decide(phi) is True:
            return ('calc',)

        # 1. hypotheses and stored lemmas cost nothing
        for i, h in enumerate(ctx):
            if h == phi:
                return ('hyp', i)
        for nm, f in self.store.items():
            if f == phi:
                return ('lemma', nm)
        if depth == 0:
            return None

        k = phi[0]

        if k == 'imp':
            c = self.prove(phi[2], depth - 1, ctx + (phi[1],))
            return ('impI', c) if c else None

        if k == 'and':
            c1 = self.prove(phi[1], depth - 1, ctx)
            if not c1:
                return None
            c2 = self.prove(phi[2], depth - 1, ctx)
            return ('andI', c1, c2) if c2 else None

        if k == 'exb':
            n = teval(phi[2])
            if n is None:
                return None
            for i in range(min(n, self.w)):
                c = self.prove(sub(phi[3], phi[1], ('n', i)), depth - 1, ctx)
                if c:
                    return ('exbI', i, c)
            return None

        if k == 'allb':
            n = teval(phi[2])
            if n is None or n > self.w:
                return None
            cs = []
            for i in range(n):
                c = self.prove(sub(phi[3], phi[1], ('n', i)), depth - 1, ctx)
                if not c:
                    return None
                cs.append(c)
            return ('allbI', cs)

        if k == 'ex':
            for t in self.witnesses(phi, ctx):
                c = self.prove(sub(phi[2], phi[1], t), depth - 1, ctx)
                if c:
                    return ('wit', t, c)
            return None

        if k == 'all':
            # (a) generalisation over a fresh eigenconstant.  The name is
            #     recorded in the certificate; the kernel checks freshness.
            nm = "e%d" % next(_eigen)
            c = self.prove(sub(phi[2], phi[1], ('c', nm)), depth - 1, ctx)
            if c:
                return ('gen', nm, c)
            # (b) induction
            x, psi = phi[1], phi[2]
            c0 = self.prove(sub(psi, x, ('n', 0)), depth - 1, ctx)
            if c0:
                step = ('all', x, ('imp', psi, sub(psi, x, ('s', ('v', x)))))
                cs = self.prove(step, depth - 1, ctx)
                if cs:
                    return ('ind', c0, cs)
            return None

        return None

    def witnesses(self, phi, ctx):
        """Candidate witness terms for Ex.

        w is exactly this list's length knob.  Numerals alone cannot witness
        a Pi-0-2 goal -- Ax Ey. x < y needs a term MENTIONING x -- so the
        symbols already in scope are offered too.  That is what lifts the
        prover from Sigma-0-1 to tier 2."""
        out = [('n', n) for n in range(self.w + 1)]
        inscope = sorted(syms(phi) | {s for h in ctx for s in syms(h)})
        for s in inscope:
            base = ('c', s)
            out.append(base)
            t = base
            for _ in range(min(self.w, 3)):
                t = ('s', t)
                out.append(t)
            out.append(('*', ('n', 2), base))
        return out


# ===========================================================================
#                             REFLECTION LADDER
# ===========================================================================
TAG = "<Ascent>"


def theta(k):
    return ('atp', TAG) if k == 0 else ('pr', TAG, "<t%d>" % (k - 1))


def climb(kernel, store, names, r, verbose=True):
    """Climb r rungs.  Each rung is a kernel call on the previous
    certificate -- Proposition 1 in code."""
    certs, level, rungs = {}, 0, []
    # theta_0 is the base case and is a stipulation, as Definition (Level-1)
    # makes it.  Everything above it is earned.
    certs[0] = ('lemma', 't0')
    store['t0'] = theta(0)
    names["<t0>"] = theta(0)

    for k in range(r):
        phi = theta(k)
        names.setdefault("<t%d>" % k, phi)
        C = certs[k]
        t0 = time.perf_counter()
        try:
            kernel.check(store, [], phi, C)
        except Reject as e:
            if verbose:
                print("    theta_%-2d REJECTED: %s" % (k, e))
            break
        level = k + 1
        dt = time.perf_counter() - t0
        rungs.append(dict(k=k, formula=show(phi), level=level,
                          kernel_calls=kernel.calls, seconds=round(dt, 5)))
        if verbose:
            print("    theta_%-2d  %-28s certified  ->  Level %d"
                  % (k, show(phi), level))
        # certified necessitation: the kernel accepted C : theta_k, so
        # nec(C) is a certificate of theta_{k+1}.
        nxt = theta(k + 1)
        names["<t%d>" % (k + 1)] = nxt
        certs[k + 1] = ('nec', C)
        store["t%d" % (k + 1)] = nxt
    return level, rungs


# ===========================================================================
#                               TARGET SUITE
# ===========================================================================
def X(n):
    return ('v', n)


TARGETS = [
    ("add_closed",  ('=', ('+', ('n', 2), ('n', 2)), ('n', 4))),
    ("bnd_lt",      ('allb', 'x', ('n', 5), ('<', X('x'), ('n', 5)))),
    ("bnd_ex",      ('exb', 'x', ('n', 9), ('=', ('*', X('x'), X('x')),
                                            ('n', 16)))),
    ("ex_solve",    ('ex', 'x', ('=', ('+', X('x'), ('n', 3)), ('n', 7)))),
    ("ex_square",   ('ex', 'x', ('=', ('*', X('x'), X('x')), ('n', 49)))),
    ("ex_big",      ('ex', 'x', ('=', ('+', X('x'), ('n', 1)), ('n', 18)))),
    ("all_succ",    ('all', 'x', ('<', X('x'), ('s', X('x'))))),
    ("all_le",      ('all', 'x', ('<=', X('x'), X('x')))),
    ("all_add0",    ('all', 'x', ('=', ('+', X('x'), ('n', 0)), X('x')))),
    ("unbounded",   ('all', 'x', ('ex', 'y', ('<', X('x'), X('y'))))),
    ("succ_exists", ('all', 'x', ('ex', 'y', ('=', X('y'),
                                              ('s', X('x')))))),
    ("min_exists",  ('ex', 'x', ('all', 'y', ('<=', X('x'), X('y'))))),
]


def run_suite(d, w, verbose=True):
    kernel = Kernel(TAG, {})
    store = {}
    S = Search(kernel, store, d, w)
    rows, solved = [], 0
    for name, phi in TARGETS:
        t0 = time.perf_counter()
        S.nodes = 0
        C = S.prove(phi)
        dt = time.perf_counter() - t0
        verdict, ok = "", False
        if C is not None:
            try:
                kernel.check(store, [], phi, C)
                ok, verdict = True, "ok"
                store[name] = phi
            except Reject as e:
                verdict = "REJECTED: %s" % e
        solved += ok
        rows.append(dict(target=name, tier=tier_name(phi),
                         formula=show(phi), proved=C is not None,
                         certified=ok, verdict=verdict,
                         nodes=S.nodes, seconds=round(dt, 4)))
        if verbose:
            print("    %-12s %-7s %-34s %s"
                  % (name, tier_name(phi), show(phi)[:34],
                     ("CERT ok, %d nodes" % S.nodes) if ok else
                     (verdict or "not proved")))
    return solved, rows, kernel


def tier_profile(rows):
    prof = defaultdict(lambda: [0, 0])
    for r in rows:
        prof[r["tier"]][1] += 1
        if r["certified"]:
            prof[r["tier"]][0] += 1
    return {k: dict(certified=v[0], targets=v[1])
            for k, v in sorted(prof.items())}


# ===========================================================================
def cmd_run(a):
    print("=" * 74)
    print("  ASCENT   d=%d (depth)   w=%d (witness)   r=%d (reflect)"
          % (a.depth, a.witness, a.reflect))
    print("=" * 74)
    print("\n  arithmetic targets\n")
    solved, rows, kernel = run_suite(a.depth, a.witness)

    print("\n  reflection ladder\n")
    names = {}
    store2 = {}
    K2 = Kernel(TAG, names)
    level, rungs = climb(K2, store2, names, a.reflect)

    prof = tier_profile(rows)
    highest = max([r["tier"] for r in rows if r["certified"]],
                  default="none", key=lambda s: (s != "none", s))
    tiers_hit = sorted({r["tier"] for r in rows if r["certified"]})

    print("\n" + "-" * 74)
    print("  certified %d/%d targets   |   tiers reached: %s"
          % (solved, len(rows), ", ".join(tiers_hit) or "none"))
    print("  lev(A) = %d   (each rung kernel-certified; r is the only cap)"
          % level)
    print("  kernel calls: %d suite + %d ladder"
          % (kernel.calls, K2.calls))
    print("-" * 74)

    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "ascent_d%d_w%d_r%d.json"
                           % (a.depth, a.witness, a.reflect)), "w") as f:
        json.dump(dict(params=dict(d=a.depth, w=a.witness, r=a.reflect),
                       certified=solved, targets=len(rows),
                       tier_profile=prof, tiers_reached=tiers_hit,
                       lev=level, rows=rows, rungs=rungs), f, indent=2)
    return 0


def cmd_grid(a):
    """Proposition 2, empirically: sweep the knobs and show what moves."""
    print("=" * 74)
    print("  PARAMETER SWEEP -- what each knob buys")
    print("=" * 74)
    print("\n  %-4s %-4s %-4s %-10s %-8s %-22s %s"
          % ("d", "w", "r", "certified", "lev", "tiers reached", "nodes"))
    print("  " + "-" * 70)
    out = []
    for d in a.depths:
        for w in a.witnesses:
            for r in a.reflects:
                solved, rows, kernel = run_suite(d, w, verbose=False)
                names, store2 = {}, {}
                K2 = Kernel(TAG, names)
                level, _ = climb(K2, store2, names, r, verbose=False)
                tiers = sorted({x["tier"] for x in rows if x["certified"]})
                nodes = sum(x["nodes"] for x in rows)
                print("  %-4d %-4d %-4d %-10s %-8d %-22s %s"
                      % (d, w, r, "%d/%d" % (solved, len(rows)), level,
                         ",".join(tiers) or "-", f"{nodes:,}"))
                out.append(dict(d=d, w=w, r=r, certified=solved,
                                targets=len(rows), lev=level,
                                tiers=tiers, nodes=nodes))
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "ascent_grid.json"), "w") as f:
        json.dump(out, f, indent=2)

    lev_by_r = defaultdict(set)
    cert_by_dw = defaultdict(set)
    for o in out:
        lev_by_r[o["r"]].add(o["lev"])
        cert_by_dw[(o["d"], o["w"])].add(o["certified"])
    ind_r = all(len(v) == 1 for v in lev_by_r.values())
    ind_dw = all(len(v) == 1 for v in cert_by_dw.values())
    print("\n  lev depends only on r : %s" % ("YES" if ind_r else "NO"))
    print("  certified count depends only on (d,w) : %s"
          % ("YES" if ind_dw else "NO"))
    print("  -> Proposition 2 holds on this grid" if (ind_r and ind_dw)
          else "  -> Proposition 2 FAILS on this grid")
    return 0


def cmd_soundness(a):
    """Hand the kernel certificates that must be rejected."""
    print("=" * 74)
    print("  KERNEL SOUNDNESS PROBES -- each of these MUST be rejected")
    print("=" * 74 + "\n")
    names = {"<f>": ('=', ('n', 0), ('n', 1))}
    K = Kernel(TAG, names)
    store = {}
    bad = [
        ("false by calc", ('=', ('n', 0), ('n', 1)), ('calc',)),
        ("lemma that is not stored",
         ('=', ('n', 0), ('n', 1)), ('lemma', 'nope')),
        ("nec for an unproved formula",
         ('pr', TAG, "<f>"), ('nec', ('calc',))),
        ("nec with the wrong tag",
         ('pr', "<Other>", "<f>"), ('nec', ('calc',))),
        ("gen from a single instance",
         ('all', 'x', ('=', X('x'), ('n', 0))),
         ('gen', 'z', ('calc',))),
        ("gen with a captured eigenvariable",
         ('all', 'x', ('=', X('x'), ('c', 'k'))),
         ('gen', 'k', ('calc',))),
        ("wit with no witness",
         ('ex', 'x', ('<', ('s', X('x')), X('x'))), ('wit', ('n', 3),
                                                     ('calc',))),
        ("induction without a base",
         ('all', 'x', ('<', X('x'), ('n', 0))),
         ('ind', ('calc',), ('calc',))),
    ]
    caught = 0
    for label, phi, C in bad:
        try:
            K.check(store, [], phi, C)
            print("  %-34s ACCEPTED  <-- UNSOUND" % label)
        except Reject as e:
            caught += 1
            print("  %-34s rejected (%s)" % (label, str(e)[:30]))
    print("\n  %d/%d rejected%s" % (caught, len(bad),
                                    "" if caught == len(bad)
                                    else "   <-- KERNEL IS UNSOUND"))
    return 0 if caught == len(bad) else 1


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-d", "--depth", type=int, default=3)
    ap.add_argument("-w", "--witness", type=int, default=10)
    ap.add_argument("-r", "--reflect", type=int, default=4)
    ap.add_argument("--out", default="results_ascent")
    ap.add_argument("--grid", action="store_true")
    ap.add_argument("--soundness", action="store_true")
    ap.add_argument("--depths", type=int, nargs="+", default=[1, 2, 3, 4])
    ap.add_argument("--witnesses", type=int, nargs="+", default=[1, 5, 20])
    ap.add_argument("--reflects", type=int, nargs="+", default=[1, 3, 8])
    a = ap.parse_args()
    if a.soundness:
        return cmd_soundness(a)
    if a.grid:
        return cmd_grid(a)
    return cmd_run(a)


if __name__ == "__main__":
    sys.exit(main())
