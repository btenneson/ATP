#!/usr/bin/env python3
r"""
run.py -- one command for the whole Arach1 pipeline.

    python run.py --quick        smoke test, ~2 minutes, proves nothing much
    python run.py                the real run: prep 12k, m=10, p=0.8, bench
    python run.py --prove peirce attempt a single theorem

Works on Windows, macOS and Linux.  Everything it writes lands in ./work/ .
The only thing you must supply is set.mm, beside this script.

Stages, and what each is for:

    check   python version, numpy, set.mm, and the module imports
    cache   parse set.mm once (~25s) so later stages start in ~2s
    prep    set.mm proofs -> v45 wff sequences -> backward search steps
    train   m independent models on random p-fractions; mean and spread
    bench   COUPLED solve rate, easy/medium/hard, against rank=None

Only the last stage answers the question.  Everything before it is setup.
"""
from __future__ import annotations
import argparse, os, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(HERE, "work")
PY = sys.executable

NEEDED = ["metamath.py", "setmm_grammar.py", "predator71.py",
          "bench_p71.py", "transcript.py", "arach1.py"]


def sh(args, title):
    print("\n" + "=" * 78)
    print("  %s" % title)
    print("  $ %s" % " ".join([os.path.basename(PY)] + args))
    print("=" * 78, flush=True)
    t0 = time.time()
    r = subprocess.run([PY] + args, cwd=HERE)
    if r.returncode != 0:
        print("\n  !! stage failed with exit code %d" % r.returncode)
        sys.exit(r.returncode)
    print("  [%.0fs]" % (time.time() - t0), flush=True)


def check():
    print("=" * 78)
    print("  Arach1 -- preflight")
    print("=" * 78)
    ok = True
    print("  python           %s" % sys.version.split()[0])
    if sys.version_info < (3, 8):
        print("    !! need Python 3.8+"); ok = False
    try:
        import numpy
        print("  numpy            %s" % numpy.__version__)
    except ImportError:
        print("    !! numpy missing:  pip install numpy"); ok = False
    for f in NEEDED:
        p = os.path.join(HERE, f)
        print("  %-16s %s" % (f, "ok" if os.path.exists(p) else "MISSING"))
        ok &= os.path.exists(p)
    smm = os.path.join(HERE, "set.mm")
    if os.path.exists(smm):
        print("  set.mm           %.1f MB" % (os.path.getsize(smm) / 1e6))
    else:
        print("  set.mm           MISSING -- download it from")
        print("                   https://github.com/metamath/set.mm")
        print("                   and put it beside this script")
        ok = False
    os.makedirs(WORK, exist_ok=True)
    print("  work dir         %s" % WORK)
    if not ok:
        sys.exit("\n  preflight failed; fix the above and re-run")
    print("\n  preflight ok")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true",
                    help="tiny smoke run, ~2 min")
    ap.add_argument("--prove", metavar="LABEL",
                    help="attempt one theorem and stop")
    ap.add_argument("--m", type=int, default=10)
    ap.add_argument("--p", type=float, default=0.8)
    ap.add_argument("--theorems", type=int, default=12000)
    ap.add_argument("--per-band", type=int, default=10)
    ap.add_argument("--budget", type=int, default=8000)
    ap.add_argument("--depth", type=int, default=6)
    ap.add_argument("--wall", type=float, default=30.0)
    ap.add_argument("--skip-prep", action="store_true")
    ap.add_argument("--skip-train", action="store_true")
    a = ap.parse_args()

    check()

    if a.prove:
        sh(["arach1.py", "prove", a.prove, "--budget", str(a.budget),
            "--depth", str(a.depth), "--wall", str(a.wall)],
           "prove %s" % a.prove)
        return 0

    if a.quick:
        a.theorems, a.m, a.per_band = 1500, 3, 3
        a.budget, a.wall = 2000, 8.0

    if not a.skip_prep:
        sh(["arach1.py", "prep", "--chunk", "0", str(a.theorems)],
           "stage 1/3  prep -- %s theorems into training steps" % a.theorems)

    if not a.skip_train:
        sh(["arach1.py", "train", "--m", str(a.m), "--p", str(a.p)],
           "stage 2/3  train -- %d resamples of a random %.0f%%"
           % (a.m, 100 * a.p))

    sh(["arach1.py", "bench", "--per-band", str(a.per_band),
        "--budget", str(a.budget), "--depth", str(a.depth),
        "--wall", str(a.wall)],
       "stage 3/3  bench -- coupled solve rate vs rank=None")

    print("\n" + "=" * 78)
    print("  done.  Read the PARENTHESISED numbers in the bench table:")
    print("  those exclude one-step duplicate lookups, which are not skill.")
    print("  Raw JSON in %s" % os.path.join(WORK, "bench.json"))
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
