#!/usr/bin/env python3
r"""
train_pairs.py -- turn set.mm proofs into training data for a search policy.

INPUT   the v45-shape transcripts from transcript.py
OUTPUT  backward search steps, chronologically split, with negatives

WHY THE PROOFS MUST BE REVERSED
-------------------------------
A v45 proof is FORWARD: line j is a direct consequence of earlier lines.  Both
Predator and Ascent search BACKWARD: they hold a goal and ask which assertion
to apply to reduce it.  Training a backward policy on forward lines teaches it
the wrong conditional.

So each proof is inverted.  Line j, justified by rule R from premise lines P,
becomes the backward step

    goal = wff(j)     ->   apply R   ->   subgoals = { wff(p) : p in P }

read root-first: the conclusion is the initial goal, the rule that produced it
is the first decision, and its premises are what remains to prove.

THE TWO LEAKS THIS AVOIDS
-------------------------
1. CANDIDATE LEAK.  The legal candidates at a step are only the assertions
   declared BEFORE the target theorem.  Scoring against all 47,572 labels lets
   the model pick an assertion that did not exist yet, and inflates every
   metric.  Candidates here are drawn from the chronological prefix.

2. SPLIT LEAK.  Splitting by STEP puts other steps of the same theorem in
   train and test.  The split here is by THEOREM, and chronological -- train on
   early set.mm, test on late -- which is also the only split that matches how
   a prover is actually used.

WHAT A NEGATIVE IS
------------------
For each step, the model must rank the true rule above assertions that were
legal and plausible but not chosen.  Negatives are sampled from prefix labels
whose conclusion has the same head symbol as the goal, which is exactly the
bucket Predator's Index.candidates() would return.  Random negatives from the
whole database make the task trivially easy and the number meaningless.

    python train_pairs.py --corpus /tmp/corpus.jsonl --out /tmp/pairs
"""
from __future__ import annotations
import argparse, json, os, pickle, random, sys, time
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.setrecursionlimit(100000)

random.seed(20260730)


def head_of(wff):
    """First token after |- .  A crude stand-in for the parse-tree head that
    Index.candidates() buckets on -- close enough to select realistic
    negatives, and it needs no grammar."""
    toks = wff.split()
    if not toks or toks[0] != "|-":
        return None
    return toks[1] if len(toks) > 1 else None


def build(a):
    print("=" * 74)
    print("  training pairs from set.mm proofs")
    print("=" * 74)

    with open(a.cache, "rb") as f:
        mm = pickle.load(f)
    order_pos = {l: i for i, l in enumerate(mm.order)}

    # conclusion head of every assertion, for negative sampling
    print("\n  indexing assertion heads...")
    by_head = defaultdict(list)
    for lab in mm.order:
        typ, data = mm.labels[lab]
        if typ not in ("$a", "$p"):
            continue
        concl = data[3]
        if not concl or concl[0] != "|-" or len(concl) < 2:
            continue
        by_head[concl[1]].append(lab)
    # sort each bucket by database position so the chronological prefix is a
    # bisect, not a linear scan.  Buckets like `wi` hold thousands of labels
    # and there are ~10^5 steps; the naive filter does not finish.
    import bisect
    for h in by_head:
        by_head[h].sort(key=lambda l: order_pos[l])
    head_pos = {h: [order_pos[l] for l in v] for h, v in by_head.items()}
    print("    %s heads, %s assertions"
          % (f"{len(by_head):,}",
             f"{sum(len(v) for v in by_head.values()):,}"))

    steps, skipped = [], Counter()
    t0 = time.time()
    n_thm = 0
    for line in open(a.corpus):
        rec = json.loads(line)
        lab = rec["label"]
        if lab not in order_pos:
            skipped["not in order"] += 1
            continue
        if not rec["proof"]:
            skipped["empty proof"] += 1
            continue
        if rec["statement"][0] != "|-":
            skipped["syntax $p"] += 1
            continue
        cut = order_pos[lab]
        n_thm += 1

        wff_of = {L["j"]: L["wff"] for L in rec["proof"]}
        for L in rec["proof"]:
            if not L["premises"]:
                continue                      # a hypothesis: a leaf, no choice
            h = head_of(L["wff"])
            if h is None:
                continue
            # legal candidates: same head, declared before this theorem
            bucket = by_head.get(h)
            if not bucket:
                skipped["no negatives"] += 1
                continue
            k = bisect.bisect_left(head_pos[h], cut)
            if k < 2:
                skipped["no negatives"] += 1
                continue
            idxs = random.sample(range(k), min(k, a.negatives + 1))
            negs = [bucket[i] for i in idxs
                    if bucket[i] != L["rule"]][:a.negatives]
            if not negs:
                skipped["no negatives"] += 1
                continue
            steps.append(dict(
                theorem=lab, pos=cut, j=L["j"],
                goal=L["wff"],
                rule=L["rule"],
                subgoals=[wff_of[p] for p in L["premises"] if p in wff_of],
                negatives=negs,
                n_legal=k))
        if a.limit and n_thm >= a.limit:
            break

    print("  %s steps from %s theorems in %.1fs"
          % (f"{len(steps):,}", f"{n_thm:,}", time.time() - t0))
    if skipped:
        print("  skipped: %s" % ", ".join("%s %d" % (k, v)
                                          for k, v in skipped.most_common()))

    # ---- chronological split BY THEOREM ---------------------------------
    thms = sorted({s["theorem"] for s in steps}, key=lambda l: order_pos[l])
    n = len(thms)
    tr = set(thms[:int(.8 * n)])
    va = set(thms[int(.8 * n):int(.9 * n)])
    split_of = {t: ("train" if t in tr else "valid" if t in va else "test")
                for t in thms}

    os.makedirs(a.out, exist_ok=True)
    counts = Counter()
    files = {s: open(os.path.join(a.out, "%s.jsonl" % s), "w")
             for s in ("train", "valid", "test")}
    for s in steps:
        sp = split_of[s["theorem"]]
        counts[sp] += 1
        files[sp].write(json.dumps(s) + "\n")
    for f in files.values():
        f.close()

    print("\n  split by theorem, chronological (train = early set.mm)")
    for sp in ("train", "valid", "test"):
        nt = sum(1 for t in thms if split_of[t] == sp)
        print("    %-6s %8s steps  %6s theorems"
              % (sp, f"{counts[sp]:,}", f"{nt:,}"))

    legal = [s["n_legal"] for s in steps]
    legal.sort()
    print("\n  candidate pool size (same head, before the theorem):")
    print("    median %s   mean %.0f   max %s"
          % (f"{legal[len(legal)//2]:,}", sum(legal) / len(legal),
             f"{legal[-1]:,}"))
    rules = Counter(s["rule"] for s in steps)
    top = rules.most_common(5)
    print("\n  most-applied rules: %s"
          % ", ".join("%s %.1f%%" % (r, 100 * c / len(steps))
                      for r, c in top))
    print("  -> a constant predictor scores %.1f%% top-1; that is the floor "
          "any M must beat" % (100 * top[0][1] / len(steps)))
    print("\n  wrote %s/{train,valid,test}.jsonl" % a.out)
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default="/tmp/corpus.jsonl")
    ap.add_argument("--cache", default="/tmp/setmm.pkl")
    ap.add_argument("--out", default="/tmp/pairs")
    ap.add_argument("--negatives", type=int, default=15)
    ap.add_argument("--limit", type=int, default=0)
    return build(ap.parse_args())


if __name__ == "__main__":
    sys.exit(main())
