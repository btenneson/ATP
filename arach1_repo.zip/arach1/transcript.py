#!/usr/bin/env python3
r"""
transcript.py -- extract v45-shape proofs from set.mm.

v45, Definition of proof:

    A proof from Gamma is a finite sequence pi = <pi(1),...,pi(n)> of members
    of y such that for each j, either pi(j) in Gamma, or pi(j) is a direct
    consequence of {pi(1),...,pi(j-1)}.  The proof length of pi is |pi| := n.

A Metamath proof is NOT that on its face: it is a sequence of LABELS in
reverse Polish order.  But the verifier's stack materialises the wffs, and
the sequence of statements pushed is exactly a linear Hilbert-style
derivation --- which is the notion above.  This is the same object as
Definition 14.1 of the cross-branch reuse document, the "verification
transcript".

So the conversion is: run the stack machine, and log each push.

    line j : wff                      justified by  rule(premise lines)

Filtering to the pushes whose statement begins with |- gives the LOGICAL
derivation; the other ~95% of pushes are formula construction, which is
syntax rather than inference (metamath.classify draws the same line).

    python transcript.py --db set.mm --label prcom
    python transcript.py --db set.mm --export corpus.jsonl --limit 5000

Brian Tenneson.  Implementation by Claude (Anthropic).
"""
from __future__ import annotations
import argparse, itertools, json, os, sys, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.setrecursionlimit(100000)

from metamath import MM, MMError, load, classify, apply_subst   # noqa: E402


def transcript(mm, label, logic_only=True):
    """Return the proof of `label` as a sequence of lines.

    Each line is a dict:
        j        1-based line number in the returned sequence
        wff      the statement, as a token list
        rule     the label justifying it ('$e'/'$f' means a hypothesis)
        premises line numbers of the earlier lines it was derived from

    This mirrors metamath.MM.verify exactly -- same stack discipline, same
    substitution -- but records provenance instead of discarding it.  It does
    NOT re-check disjoint-variable conditions; verify() is the authority on
    soundness and should be run separately."""
    _dvs, _f_hyps, _e_hyps, conclusion = mm.labels[label][1]
    proof = mm.decompress(label, mm.proofs[label])
    if "?" in proof:
        raise MMError("%s: incomplete proof" % label)

    stack = []          # entries: (statement, line_index_or_None)
    lines = []          # the emitted sequence

    def emit(stat, rule, premises):
        if logic_only and (not stat or stat[0] != "|-"):
            return None
        lines.append(dict(j=len(lines) + 1, wff=list(stat),
                          rule=rule, premises=premises))
        return len(lines)

    for step in proof:
        if step not in mm.labels:
            raise MMError("%s: unknown label %s" % (label, step))
        typ, data = mm.labels[step]

        if typ in ("$e", "$f"):
            stat = list(data)
            idx = emit(stat, step, [])          # a hypothesis line
            stack.append((stat, idx))
            continue

        s_dvs, s_f, s_e, s_concl = data
        npop = len(s_f) + len(s_e)
        if npop > len(stack):
            raise MMError("%s: stack underflow at %s" % (label, step))
        base = len(stack) - npop

        subst = {}
        for k, (_, tc, var) in enumerate(s_f):
            entry = stack[base + k][0]
            if entry[0] != tc:
                raise MMError("%s: type mismatch at %s" % (label, step))
            subst[var] = entry[1:]

        prem = [stack[base + k][1] for k in range(npop)
                if stack[base + k][1] is not None]
        del stack[base:]
        stat = apply_subst(s_concl, subst)
        idx = emit(stat, step, prem)
        stack.append((stat, idx))

    if len(stack) != 1 or stack[0][0] != conclusion:
        raise MMError("%s: transcript did not reduce to the statement"
                      % label)
    return lines


def show(lines, width=88):
    print("  %-4s %-14s %-10s %s" % ("line", "rule", "from", "wff"))
    print("  " + "-" * (width - 2))
    for L in lines:
        w = " ".join(L["wff"])
        if len(w) > width - 34:
            w = w[:width - 37] + "..."
        print("  %-4d %-14s %-10s %s"
              % (L["j"], L["rule"],
                 ",".join(map(str, L["premises"])) or "--", w))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="set.mm")
    ap.add_argument("--cache", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "work", "setmm.pkl"))
    ap.add_argument("--label", default=None)
    ap.add_argument("--export", default=None,
                    help="write the whole corpus as JSONL")
    ap.add_argument("--limit", type=int, default=2000)
    ap.add_argument("--all-lines", action="store_true",
                    help="include formula-construction lines too")
    a = ap.parse_args()

    if a.cache and os.path.exists(a.cache):
        import pickle
        t0 = time.time()
        with open(a.cache, "rb") as f:
            mm = pickle.load(f)
        print("  cache loaded in %.1fs" % (time.time() - t0))
    else:
        mm = load(a.db, say=lambda s: print("  " + s))
        if a.cache:
            import pickle
            with open(a.cache, "wb") as f:
                pickle.dump(mm, f, protocol=5)

    if a.label:
        lines = transcript(mm, a.label, logic_only=not a.all_lines)
        stat = " ".join(mm.labels[a.label][1][3])
        print("\n  %s :  %s" % (a.label, stat))
        print("  v45 proof length |pi| = %d\n" % len(lines))
        show(lines)
        return 0

    if a.export:
        thms = [l for l in mm.order if mm.labels[l][0] == "$p"][:a.limit]
        n = ok = 0
        lens = []
        t0 = time.time()
        with open(a.export, "w") as f:
            for lab in thms:
                n += 1
                try:
                    lines = transcript(mm, lab, logic_only=not a.all_lines)
                except (MMError, RecursionError, KeyError, ValueError):
                    continue
                ok += 1
                lens.append(len(lines))
                f.write(json.dumps(dict(
                    label=lab,
                    statement=list(mm.labels[lab][1][3]),
                    hypotheses=[list(s) for _, s
                                in mm.labels[lab][1][2]],
                    proof=[dict(j=L["j"], wff=" ".join(L["wff"]),
                                rule=L["rule"], premises=L["premises"])
                           for L in lines])) + "\n")
        lens.sort()
        print("\n  exported %d/%d proofs to %s in %.1fs"
              % (ok, n, a.export, time.time() - t0))
        if lens:
            print("  |pi|:  min %d   median %d   mean %.1f   max %d"
                  % (lens[0], lens[len(lens) // 2],
                     sum(lens) / len(lens), lens[-1]))
        return 0

    ap.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
