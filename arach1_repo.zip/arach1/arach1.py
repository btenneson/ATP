#!/usr/bin/env python3
r"""
ARACH1  =  Predator_7.1  x  M

Predator supplies the calculus, the certificates and the verifier.  M supplies
the ordering.  M is never trusted: it only permutes the candidate list, so a
wrong M costs time and can never cost soundness.  Every proof Arach1 emits is
still checked by metamath.py, exactly as before.

WHY THE COUPLING IS THE LEVERAGE
--------------------------------
Breadth-first search touches ~b^d nodes.  On set.mm the measured median
candidate pool is b = 4735, so d = 6 is ~1e22 and depth is useless.  Move the
true assertion into the top 20 and the same depth costs 6.4e7; into the top 5
and it costs 1.6e4.  M does not prove anything.  M collapses b.

Predator already exposes the hook, and no caller had ever passed it:

    sc_c = rank(gt, closers) if rank else [0.0]*len(closers)
    sc_o = rank(gt, openers) if rank else [0.0]*len(openers)
    pick = (closers by -sc_c) + (openers by -sc_o)[:48]

That 48 is the whole point.  Openers are CAPPED, so an unranked Predator keeps
an arbitrary 48 of several thousand.  Same 48 slots, filled by score.

USAGE
-----
    python arach1.py prep                       # once; ~minutes
    python arach1.py train --m 10 --p 0.8       # m resamples of a random p
    python arach1.py eval  --n 40               # coupled solve rate vs base
    python arach1.py bench                      # easy / medium / hard

`train` reports RANKING accuracy, which is a proxy.  `eval` and `bench` report
SOLVE RATE against an identical run with rank=None, in the same process at the
same budget.  Only the second kind of number answers the question.

Put set.mm beside this script; the parse cache builds itself on first use
and lands in ./work/ .  Requires numpy and nothing else.

Brian Tenneson.  Implementation by Claude (Anthropic).
"""
from __future__ import annotations
import argparse, bisect, itertools, json, os, pickle, sys, time
from collections import Counter, defaultdict

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.setrecursionlimit(100000)

# Portable paths: everything lives beside this script, not in /tmp, which
# does not exist on Windows.
HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(HERE, "work")
os.makedirs(WORK, exist_ok=True)
CACHE = os.path.join(WORK, "setmm.pkl")
STEPS = os.path.join(WORK, "arach1_steps.npz")
MODEL = os.path.join(WORK, "arach1_model.pkl")
SETMM = os.path.join(HERE, "set.mm")
_KIND = {}   # label -> "logic"/"syntax", filled by _setup_eval

FEATS = ["log_freq", "jaccard", "cover_goal", "len_ratio",
         "abs_len_diff", "n_ehyp", "is_closer", "db_pos", "bias"]
F_FREQ = 0                      # column filled in per-resample, see cmd_train


def featurise(gset, glen, concl, nfreq, dbpos, n_e):
    """Cheap by construction: evaluated once per candidate per expansion."""
    c = set(concl)
    inter = len(gset & c)
    union = len(gset | c) or 1
    lc = len(concl) or 1
    lg = glen or 1
    return (nfreq, inter / union, inter / (len(gset) or 1), lc / lg,
            abs(lc - lg) / max(lc, lg), float(n_e),
            1.0 if n_e == 0 else 0.0, dbpos, 1.0)


def load_mm():
    if not os.path.exists(CACHE):
        if not os.path.exists(SETMM):
            sys.exit("need set.mm beside arach1.py (or a cache at %s)" % CACHE)
        print("  no cache; parsing %s once (~25s)..." % SETMM)
        from metamath import load
        mm = load(SETMM, say=lambda s: print("   ", s))
        with open(CACHE, "wb") as f:
            pickle.dump(mm, f, protocol=5)
        print("  cached to %s" % CACHE)
        return mm
    with open(CACHE, "rb") as f:
        return pickle.load(f)


def tables(mm):
    pos = {l: i for i, l in enumerate(mm.order)}
    n = len(mm.order)
    meta = {}
    for lab in mm.order:
        typ, data = mm.labels[lab]
        if typ in ("$a", "$p") and data[3][:1] == ["|-"]:
            meta[lab] = (data[3][1:], len(data[2]), pos[lab] / n)
    return pos, meta, n


# ===========================================================================
#  stage 1 -- prep
# ===========================================================================
def cmd_prep(a):
    from transcript import transcript
    from metamath import MMError

    mm = load_mm()
    pos, meta, nlab = tables(mm)
    lab_id = {l: i for i, l in enumerate(sorted(meta))}

    by_head = defaultdict(list)
    for lab, (concl, _ne, _dp) in meta.items():
        if concl:
            by_head[concl[0]].append(lab)
    for h in by_head:
        by_head[h].sort(key=lambda l: pos[l])
    hpos = {h: [pos[l] for l in v] for h, v in by_head.items()}

    thms = [l for l in mm.order
            if mm.labels[l][0] == "$p" and mm.labels[l][1][3][:1] == ["|-"]]
    lo, hi = a.chunk
    thms = thms[lo:hi]
    print("  preparing %s theorems [%d:%d]" % (f"{len(thms):,}", lo, hi))

    rng = np.random.default_rng(0)
    X, LAB, TP, ISP, GRP = [], [], [], [], []
    g = -1
    t0 = time.time()
    for n_done, lab in enumerate(thms, 1):
        try:
            lines = transcript(mm, lab, logic_only=True)
        except (MMError, RecursionError, KeyError, ValueError):
            continue
        cut = pos[lab]
        for L in lines:
            if not L["premises"]:
                continue                       # hypothesis: a leaf, no choice
            toks = L["wff"]
            if len(toks) < 2:
                continue
            bucket = by_head.get(toks[1])
            if not bucket:
                continue
            k = bisect.bisect_left(hpos[toks[1]], cut)   # chronological prefix
            if k < 2:
                continue
            true = L["rule"]
            if true not in meta:
                continue
            sel = rng.choice(k, size=min(k, a.negatives), replace=False)
            negs = [bucket[i] for i in sel if bucket[i] != true]
            if not negs:
                continue
            gset, glen = set(toks[1:]), len(toks) - 1
            g += 1
            for c in [true] + negs:
                cc, ne, dp = meta[c]
                X.append(featurise(gset, glen, cc, 0.0, dp, ne))
                LAB.append(lab_id[c])
                TP.append(cut)
                ISP.append(1 if c == true else 0)
                GRP.append(g)
        if a.progress and n_done % a.progress == 0:
            print("    %s/%s   %s groups   %.0fs"
                  % (f"{n_done:,}", f"{len(thms):,}", f"{g+1:,}",
                     time.time() - t0))

    out = a.out or STEPS
    Xa = np.array(X, dtype=np.float32)
    pack = dict(X=Xa, lab=np.array(LAB, dtype=np.int32),
                tp=np.array(TP, dtype=np.int32),
                isp=np.array(ISP, dtype=np.int8),
                grp=np.array(GRP, dtype=np.int64),
                nlab=np.array([len(lab_id)]))
    if a.append and os.path.exists(out):
        old = np.load(out)
        pack = dict(
            X=np.vstack([old["X"], pack["X"]]),
            lab=np.concatenate([old["lab"], pack["lab"]]),
            tp=np.concatenate([old["tp"], pack["tp"]]),
            isp=np.concatenate([old["isp"], pack["isp"]]),
            grp=np.concatenate([old["grp"],
                                pack["grp"] + old["grp"].max() + 1]),
            nlab=old["nlab"])
    np.savez_compressed(out, **pack)
    print("  %s rows, %s groups -> %s  (%.1fs)"
          % (f"{len(pack['X']):,}", f"{pack['grp'].max()+1:,}", out,
             time.time() - t0))
    return 0


# ===========================================================================
#  stage 2 -- train
# ===========================================================================
def fit(Dn, epochs, lr=1.0, l2=1e-6, seed=0):
    """Pairwise logistic on SCALED differences.

    Scaled, never centred.  Centring them was the first version of this and it
    deleted the signal: the mean of (positive - negative) is exactly what
    separates a chosen rule from an unchosen one.  That bug gave 0.9% top-1
    against a 59.7% prior -- worse than random -- from a single line."""
    rng = np.random.default_rng(seed)
    n, d = Dn.shape
    w = rng.normal(0, 0.01, d)
    v = np.zeros(d)
    for _ in range(epochs):
        z = np.clip(Dn @ w, -30, 30)
        p = 1.0 / (1.0 + np.exp(-z))
        g = Dn.T @ (p - 1.0) / n + l2 * w
        v = 0.9 * v + g
        w -= lr * v
    return w, float((Dn @ w > 0).mean())


def group_bounds(grp):
    starts = np.flatnonzero(np.diff(grp, prepend=grp[0] - 1))
    ends = np.append(starts[1:], len(grp))
    return starts, ends


def cmd_train(a):
    z = np.load(a.steps or STEPS)
    X = z["X"].astype(np.float64)
    lab, tp, isp, grp = z["lab"], z["tp"], z["isp"], z["grp"]
    starts, ends = group_bounds(grp)
    ng = len(starts)
    print("=" * 74)
    print("  ARACH1 -- training M    m=%d resamples, p=%.2f, %s split"
          % (a.m, a.p, a.split))
    print("=" * 74)
    print("\n  %s rows in %s decision groups, mean %.1f candidates/group"
          % (f"{len(X):,}", f"{ng:,}", len(X) / ng))

    gpos = tp[starts]
    res = []
    for run in range(a.m):
        rng = np.random.default_rng(1000 + run)
        if a.split == "random":
            trm = rng.random(ng) < a.p
        else:
            trm = gpos <= np.quantile(gpos, a.p)
        tri, tei = np.flatnonzero(trm), np.flatnonzero(~trm)

        # log-frequency of each label among TRAIN positives only.  Deriving it
        # from the whole database would leak the held-out theorems into the
        # policy, and this is the single strongest feature -- it is what the
        # frequency-prior baseline is made of.
        freq = Counter()
        for gi in tri:
            s, e = starts[gi], ends[gi]
            freq[int(lab[s + int(np.argmax(isp[s:e]))])] += 1
        nf = np.zeros(int(z["nlab"][0]) + 1)
        for k, v in freq.items():
            nf[k] = np.log1p(v)
        Xr = X.copy()
        Xr[:, F_FREQ] = nf[lab]

        P, N = [], []
        for gi in tri:
            s, e = starts[gi], ends[gi]
            pi = s + int(np.argmax(isp[s:e]))
            for i in range(s, e):
                if i != pi:
                    P.append(Xr[pi]); N.append(Xr[i])
        P, N = np.array(P), np.array(N)
        sd = np.vstack([P, N]).std(0) + 1e-9
        w, pacc = fit((P - N) / sd, a.epochs, seed=run)

        t1 = tk = b1 = 0
        ranks = []
        for gi in tei:
            s, e = starts[gi], ends[gi]
            truth = int(np.argmax(isp[s:e]))
            sc = (Xr[s:e] / sd) @ w
            r = int(np.flatnonzero(np.argsort(-sc) == truth)[0]) + 1
            ranks.append(r)
            t1 += (r == 1); tk += (r <= a.topk)
            b1 += (int(np.argmax(Xr[s:e, F_FREQ])) == truth)
        ranks = np.array(ranks)
        n_te = len(tei)
        res.append(dict(run=run, w=w, sd=sd, nf=nf, pacc=pacc,
                        top1=t1 / n_te, topk=tk / n_te, base1=b1 / n_te,
                        med=float(np.median(ranks))))
        print("  run %-2d  pairwise %.1f%%  |  prior %5.1f%%   M %5.1f%%"
              "  (top-%d %5.1f%%)   median rank %.0f"
              % (run, 100 * pacc, 100 * b1 / n_te, 100 * t1 / n_te,
                 a.topk, 100 * tk / n_te, np.median(ranks)))

    t1s = np.array([r["top1"] for r in res])
    bls = np.array([r["base1"] for r in res])
    tks = np.array([r["topk"] for r in res])
    print("\n  over %d resamples of a random %.0f%%" % (a.m, 100 * a.p))
    print("    frequency prior  top-1  %5.1f%% +/- %.1f"
          % (100 * bls.mean(), 100 * bls.std()))
    print("    M                top-1  %5.1f%% +/- %.1f"
          % (100 * t1s.mean(), 100 * t1s.std()))
    print("    M                top-%-2d %5.1f%% +/- %.1f"
          % (a.topk, 100 * tks.mean(), 100 * tks.std()))
    print("    delta            top-1  %+5.1f pts"
          % (100 * (t1s.mean() - bls.mean())))

    best = max(res, key=lambda r: r["top1"])
    with open(a.model or MODEL, "wb") as f:
        pickle.dump(dict(w=best["w"], sd=best["sd"], nf=best["nf"],
                         feats=FEATS), f)
    print("\n  best run %d -> %s" % (best["run"], a.model or MODEL))
    print("  Ranking accuracy is a PROXY.  Run `eval` or `bench` for the")
    print("  coupled solve rate, which is the number that matters.")
    return 0


# ===========================================================================
#  stage 3 -- the coupled prover
# ===========================================================================
def make_rank(model, meta, lab_index):
    """Build the `rank` callable Predator's prove() expects.

    SPEED IS A CORRECTNESS CONCERN HERE.  rank() is called on every expansion
    against the whole candidate bucket -- a median of 4,735 assertions on
    set.mm.  The first version built a 4735x9 numpy array per call and was so
    slow the evaluation could not finish a single target; the policy has to be
    cheap enough to live inside the loop it is steering.

    So the five goal-INDEPENDENT features (log_freq, n_ehyp, is_closer,
    db_pos, bias) are folded into one scalar per label, once, at construction.
    Per candidate per expansion only four goal-dependent features remain, and
    they all fall out of a single set intersection."""
    w, sd, nf = model["w"], model["sd"], model["nf"]
    c = w / sd                                   # per-feature coefficient

    static, cset, clen = {}, {}, {}
    for lb, (concl, n_e, dp) in meta.items():
        i = lab_index.get(lb)
        static[lb] = (c[0] * (nf[i] if i is not None else 0.0)
                      + c[5] * float(n_e)
                      + c[6] * (1.0 if n_e == 0 else 0.0)
                      + c[7] * dp + c[8])
        cset[lb] = set(concl)
        clen[lb] = len(concl) or 1
    c1, c2, c3, c4 = c[1], c[2], c[3], c[4]

    def rank(gt, cands):
        if not cands:
            return []
        gset = set(gt.tokens())
        ng = len(gset) or 1
        lg = ng
        out = []
        for lb, _t, data in cands:
            cs = cset.get(lb)
            if cs is None:
                concl = data[3][1:] if data[3][:1] == ["|-"] else data[3]
                cs, lc = set(concl), len(concl) or 1
                st = c[7] * 0.5 + c[8]
            else:
                lc, st = clen[lb], static[lb]
            inter = len(gset & cs)
            union = ng + lc - inter or 1
            out.append(st + c1 * (inter / union) + c2 * (inter / ng)
                       + c3 * (lc / lg) + c4 * (abs(lc - lg) / max(lc, lg)))
        return out
    return rank


def _setup_eval(a):
    import setmm_grammar as G
    from metamath import classify
    mm = load_mm()
    by_tc = G.build_grammar(mm)
    kind = classify(mm)
    _KIND.clear(); _KIND.update(kind)
    pos, meta, nlab = tables(mm)
    lab_index = {l: i for i, l in enumerate(sorted(meta))}
    with open(a.model or MODEL, "rb") as f:
        model = pickle.load(f)
    rank = make_rank(model, meta, lab_index)
    fvar, fallback = {}, {}
    for lab in mm.order:
        typ, d = mm.labels[lab]
        if typ == "$f":
            fvar.setdefault(d[1], lab)
            fallback.setdefault(d[0], G.Tree(None, d[0], (), d[1]))
    return mm, by_tc, kind, pos, rank, fvar, fallback


class _Deadline(Exception):
    pass


def _duel(mm, by_tc, pos, idx, lab, rank, fvar, fallback, budget, depth,
          wall=20.0):
    """Run the identical target with rank=None and rank=M -- same process,
    same budget, same index state, same wall clock.  Anything else is not a
    comparison.

    prove() has no timeout of its own; passing a `say` that raises at a
    deadline is the non-invasive hook, and progress=20 keeps the check
    frequent enough that a slow expansion cannot overshoot badly."""
    import setmm_grammar as G
    import predator71 as P
    from bench_p71 import certify
    stat = mm.labels[lab][1][3]
    try:
        gt = G.parse(stat[1:], "wff", by_tc)
    except Exception:
        return None
    if gt is None:
        return None
    out = {}
    for name, rk in (("base", None), ("arach", rank)):
        P._counter = itertools.count(1)
        end = time.perf_counter() + wall
        def tick(_m, _end=end):
            if time.perf_counter() > _end:
                raise _Deadline()
        t0 = time.perf_counter()
        try:
            res, exp = P.prove(gt, idx, budget, depth, rank=rk,
                               say=tick, progress=20)
        except _Deadline:
            res, exp = None, -1
        except RecursionError:
            res, exp = None, -2
        dt = time.perf_counter() - t0
        ok, verdict, nlog = False, "", 0
        if res is not None:
            root, sub = res
            try:
                proof = root.emit(sub, fvar, fallback)
                verdict = certify(mm, lab, stat, proof)
                ok = verdict == "ok"
                nlog = sum(1 for st in proof if _KIND.get(st) == "logic")
            except Exception:
                verdict = "emit failed"
        out[name] = dict(ok=ok, exp=exp, sec=round(dt, 2), cv=verdict,
                         steps=nlog)
    return out


def cmd_prove(a):
    """Attempt ONE theorem with the trained coupling."""
    from bench_p71 import IncIndex, logic_depth, certify
    from metamath import classify
    import setmm_grammar as G
    import predator71 as P

    mm, by_tc, kind, pos, rank, fvar, fallback = _setup_eval(a)
    lab = a.label
    if lab not in mm.labels:
        sys.exit("no such label: %s" % lab)
    stat = mm.labels[lab][1][3]
    if mm.labels[lab][1][2]:
        sys.exit("%s has $e hypotheses; Arach1 targets closed theorems "
                 "(the bare conclusion is not a theorem)" % lab)

    print("=" * 76)
    print("  ARACH1   prove  %s" % lab)
    print("=" * 76)
    print("\n  goal        %s" % " ".join(stat))
    print("  human proof %s logical steps" % logic_depth(mm, kind, lab))
    print("  base        all assertions before %s" % lab)
    print("  budget %s   depth %d   wall %.0fs/side"
          % (f"{a.budget:,}", a.depth, a.wall))

    idx = IncIndex(mm, by_tc)
    t0 = time.time()
    idx.advance_to(pos[lab])
    print("  indexed %s assertions in %.1fs\n" % (f"{idx.n:,}",
                                                  time.time() - t0))

    r = _duel(mm, by_tc, pos, idx, lab, rank, fvar, fallback,
              a.budget, a.depth, a.wall)
    if r is None:
        sys.exit("  goal does not parse")
    for nm, title in (("base", "Predator alone (rank=None)"),
                      ("arach", "Arach1        (rank=M)")):
        t = r[nm]
        hd = logic_depth(mm, kind, lab)
        print("  %-28s %s  CV:%s"
              % (title, _fmt(t, hd), t["cv"] or "--"))

    if r["arach"]["ok"] and not r["base"]["ok"]:
        print("\n  M made the difference on this target.")
    elif r["base"]["ok"] and not r["arach"]["ok"]:
        print("\n  M HURT on this target -- worth recording, not hiding.")
    print()
    return 0


def _fmt(t, hd):
    if t["ok"]:
        tag = "PROVED"
        if t["steps"] == 1 and hd and hd > 1:
            tag = "lookup"          # closed by a duplicate already in the base
        return "%-7s %5s exp %5.1fs %2d st" % (tag, f"{t['exp']:,}",
                                               t["sec"], t["steps"])
    why = ("wall" if t["exp"] == -1 else
           "recur" if t["exp"] == -2 else f"{t['exp']:,}")
    return "%-7s %5s exp %5.1fs      " % ("--", why, t["sec"])


def _report(rows, title):
    n = len(rows)
    gen = lambda k: sum(1 for r in rows if r[k]["ok"]
                        and not (r[k]["steps"] == 1 and (r["hd"] or 0) > 1))
    b, c = sum(r["base"]["ok"] for r in rows), sum(r["arach"]["ok"]
                                                   for r in rows)
    gb, gc = gen("base"), gen("arach")
    bad = sum(1 for r in rows for k in ("base", "arach")
              if r[k]["cv"] not in ("", "ok"))
    print("\n  %-8s Predator %d/%d (genuine %d)   Arach1 %d/%d (genuine %d)"
          "   delta %+d   CV rej %d"
          % (title, b, n, gb, c, n, gc, gc - gb, bad))
    return b, c, n, bad, gb, gc


def cmd_eval(a):
    from bench_p71 import IncIndex, logic_depth
    mm, by_tc, kind, pos, rank, fvar, fallback = _setup_eval(a)
    thms = [l for l in mm.order
            if mm.labels[l][0] == "$p" and not mm.labels[l][1][2]
            and mm.labels[l][1][3][:1] == ["|-"]]
    held = thms[int(a.p * len(thms)):]
    picked = []
    for l in held:
        d = logic_depth(mm, kind, l)
        if d is not None and 1 <= d <= a.max_logic:
            picked.append(l)
        if len(picked) >= a.n:
            break

    print("=" * 76)
    print("  ARACH1 coupled evaluation -- held-out last %.0f%% of set.mm"
          % (100 * (1 - a.p)))
    print("  %d targets, closed, human logic depth <= %d, budget %s depth %d"
          % (len(picked), a.max_logic, f"{a.budget:,}", a.depth))
    print("=" * 76)
    print("\n  %-14s %-4s %-24s %-24s" % ("target", "hd",
                                          "Predator (rank=None)",
                                          "Arach1 (rank=M)"))
    print("  " + "-" * 70)
    idx = IncIndex(mm, by_tc)
    rows = []
    for lab in picked:
        idx.advance_to(pos[lab])
        r = _duel(mm, by_tc, pos, idx, lab, rank, fvar, fallback,
                  a.budget, a.depth, a.wall)
        if r is None:
            continue
        r["label"] = lab
        r["hd"] = logic_depth(mm, kind, lab)
        rows.append(r)
        print("  %-14s %-4s %-26s %-26s"
              % (lab, r["hd"], _fmt(r["base"], r["hd"]),
                 _fmt(r["arach"], r["hd"])))
    _report(rows, "TOTAL")
    with open(a.out or os.path.join(WORK, "eval.json"), "w") as f:
        json.dump(rows, f, indent=2)
    return 0


def cmd_bench(a):
    """Graded benchmark: easy / medium / hard, by human logical proof length."""
    from bench_p71 import IncIndex, logic_depth
    mm, by_tc, kind, pos, rank, fvar, fallback = _setup_eval(a)
    BANDS = [("easy", 1, 2), ("medium", 3, 5), ("hard", 6, 12)]

    thms = [l for l in mm.order
            if mm.labels[l][0] == "$p" and not mm.labels[l][1][2]
            and mm.labels[l][1][3][:1] == ["|-"]]
    held = thms[int(a.p * len(thms)):]
    buckets = {n: [] for n, _, _ in BANDS}
    for l in held:
        d = logic_depth(mm, kind, l)
        if d is None:
            continue
        for nm, lo, hi in BANDS:
            if lo <= d <= hi and len(buckets[nm]) < a.per_band:
                buckets[nm].append((l, d))
        if all(len(v) >= a.per_band for v in buckets.values()):
            break

    print("=" * 76)
    print("  ARACH1 graded benchmark -- held-out last %.0f%% of set.mm"
          % (100 * (1 - a.p)))
    print("  easy = 1-2 logic steps, medium = 3-5, hard = 6-12")
    print("  budget %s, depth %d" % (f"{a.budget:,}", a.depth))
    print("=" * 76)

    idx = IncIndex(mm, by_tc)
    allrows, summary = [], []
    for nm, _lo, _hi in BANDS:
        rows = []
        print("\n  --- %s (%d targets) ---" % (nm, len(buckets[nm])))
        print("  %-14s %-4s %-24s %-24s" % ("target", "hd",
                                            "Predator", "Arach1"))
        for lab, d in buckets[nm]:
            idx.advance_to(pos[lab])
            r = _duel(mm, by_tc, pos, idx, lab, rank, fvar, fallback,
                      a.budget, a.depth, a.wall)
            if r is None:
                continue
            r["label"], r["hd"], r["band"] = lab, d, nm
            rows.append(r); allrows.append(r)
            print("  %-14s %-4s %-26s %-26s"
                  % (lab, d, _fmt(r["base"], d), _fmt(r["arach"], d)))
        if rows:
            summary.append((nm,) + _report(rows, nm))

    print("\n" + "=" * 76)
    print("  %-8s %12s %12s %8s %8s"
          % ("band", "Predator", "Arach1", "delta", "CV rej"))
    for nm, b, c, n, bad, gb, gc in summary:
        print("  %-8s %12s %12s %+8d %8d"
              % (nm, "%d/%d (%d)" % (b, n, gb), "%d/%d (%d)" % (c, n, gc),
                 gc - gb, bad))
    print("  parenthesised = GENUINE solves; a 1-logic-step proof of a")
    print("  multi-step theorem is a duplicate already in the base, not skill.")
    print("=" * 76)
    with open(a.out or os.path.join(WORK, "bench.json"), "w") as f:
        json.dump(allrows, f, indent=2)
    return 0


# ===========================================================================
def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("prep", help="extract steps and features")
    p.add_argument("--chunk", type=int, nargs=2, default=[0, 12000])
    p.add_argument("--negatives", type=int, default=15)
    p.add_argument("--progress", type=int, default=1500)
    p.add_argument("--out", default=None)
    p.add_argument("--append", action="store_true")

    p = sub.add_parser("train", help="m resamples of a random fraction p")
    p.add_argument("--m", type=int, default=10)
    p.add_argument("--p", type=float, default=0.8)
    p.add_argument("--split", choices=["random", "chrono"], default="random")
    p.add_argument("--epochs", type=int, default=400)
    p.add_argument("--topk", type=int, default=5)
    p.add_argument("--steps", default=None)
    p.add_argument("--model", default=None)

    for nm, hlp in (("eval", "coupled solve rate on held-out theorems"),
                    ("bench", "graded easy / medium / hard benchmark"),
                    ("prove", "attempt ONE theorem with the coupling")):
        p = sub.add_parser(nm, help=hlp)
        p.add_argument("--p", type=float, default=0.8)
        p.add_argument("--budget", type=int, default=4000)
        p.add_argument("--depth", type=int, default=6)
        p.add_argument("--wall", type=float, default=20.0)
        p.add_argument("--model", default=None)
        p.add_argument("--out", default=None)
        if nm == "eval":
            p.add_argument("--n", type=int, default=30)
            p.add_argument("--max-logic", type=int, default=4)
        elif nm == "bench":
            p.add_argument("--per-band", type=int, default=10)
        else:
            p.add_argument("label")

    a = ap.parse_args()
    return dict(prep=cmd_prep, train=cmd_train, eval=cmd_eval,
                bench=cmd_bench, prove=cmd_prove)[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
